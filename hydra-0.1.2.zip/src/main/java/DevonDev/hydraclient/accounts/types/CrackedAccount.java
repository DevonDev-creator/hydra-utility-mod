

package DevonDev.hydraclient.accounts.types;

import DevonDev.hydraclient.accounts.Account;
import DevonDev.hydraclient.accounts.AccountType;
import net.minecraft.client.util.Session;

public class CrackedAccount extends Account<CrackedAccount> {
    public CrackedAccount(String name) {
        super(AccountType.Cracked, name);

    }

    @Override
    public boolean fetchInfo() {
        cache.username = name;
        return true;
    }

    @Override
    public boolean fetchHead() {
        return cache.makeHead("http://hydraclient.com:8082/steve.png");
    }

    @Override
    public boolean login() {
        super.login();

        setSession(new Session(name, "", "", "mojang"));
        return true;
    }
}
