

package DevonDev.hydraclient.accounts.gui;

import DevonDev.hydraclient.accounts.types.CrackedAccount;
import DevonDev.hydraclient.gui.screens.WindowScreen;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.gui.widgets.WTextBox;

public class AddCrackedAccountScreen extends WindowScreen {
    public AddCrackedAccountScreen() {
        super("Add Cracked Account", true);

        // Name
        add(new WLabel("Name:"));
        WTextBox name = add(new WTextBox("", 400)).getWidget();
        name.setFocused(true);
        row();

        // Add
        WButton add = add(new WButton("Add")).fillX().expandX().getWidget();
        add.action = () -> {
            if (!name.getText().isEmpty()) {
                AccountsScreen.addAccount(add, this, new CrackedAccount(name.getText()));
            }
        };
    }
}
