

package DevonDev.hydraclient.accounts.gui;

import DevonDev.hydraclient.accounts.types.TheAlteningAccount;
import DevonDev.hydraclient.gui.screens.WindowScreen;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.gui.widgets.WTextBox;

public class AddTheAlteningAccountScreen extends WindowScreen {
    public AddTheAlteningAccountScreen() {
        super("Add The Altening Account", true);

        // Token
        add(new WLabel("Token:"));
        WTextBox token = add(new WTextBox("", 400)).getWidget();
        token.setFocused(true);
        row();

        // Add
        WButton add = add(new WButton("Add")).fillX().expandX().getWidget();
        add.action = () -> {
            if (!token.getText().isEmpty()) {
                AccountsScreen.addAccount(add, this, new TheAlteningAccount(token.getText()));
            }
        };
    }
}
