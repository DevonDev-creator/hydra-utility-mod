

package DevonDev.hydraclient.accounts;

public enum AccountType {
    Cracked,
    Premium,
    TheAltening
}
