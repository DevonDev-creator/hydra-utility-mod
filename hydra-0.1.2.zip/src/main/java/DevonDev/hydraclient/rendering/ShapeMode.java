package DevonDev.hydraclient.rendering;

public enum ShapeMode {
    Lines,
    Sides,
    Both
}
