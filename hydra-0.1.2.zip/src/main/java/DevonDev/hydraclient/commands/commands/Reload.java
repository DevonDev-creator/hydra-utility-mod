

package DevonDev.hydraclient.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.commands.Command;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Reload extends Command {
    public Reload() {
        super("reload", "Reloads the config, modules, friends, macros and accounts.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            HydraClient.INSTANCE.load();

            return SINGLE_SUCCESS;
        });
    }
}
