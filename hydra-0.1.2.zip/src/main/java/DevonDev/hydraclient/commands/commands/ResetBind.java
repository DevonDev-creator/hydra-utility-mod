

package DevonDev.hydraclient.commands.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.commands.arguments.ModuleArgumentType;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.utils.Chat;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class ResetBind extends Command {
    public ResetBind() {
        super("reset-bind", "Resets a module keybind.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("module", ModuleArgumentType.module())
                .executes(context -> {
                    Module module = context.getArgument("module", Module.class);

                    module.setKey(-1);
                    Chat.info("This bind has been reset.");

                    return SINGLE_SUCCESS;
                }));
    }
}
