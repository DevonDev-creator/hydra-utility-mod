package DevonDev.hydraclient.commands.commands;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.commands.arguments.ModuleArgumentType;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.modules.combat.Swarm;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class SwarmModuleToggle extends Command {

    public SwarmModuleToggle() {
        super("s", "(highlight)module <module> <true/false>(default) - Toggle a module on or off.");
    }


    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("module").then(argument("m", ModuleArgumentType.module()).then(argument("bool", BoolArgumentType.bool()).executes(context -> {
            Swarm swarm = ModuleManager.INSTANCE.get(Swarm.class);
            if (swarm.currentMode.get() == Swarm.Mode.QUEEN && swarm.server != null) {
                swarm.server.sendMessage(context.getInput());
            } else {
                ToggleModule module = (ToggleModule) context.getArgument("m", Module.class);
                if (module.isActive() != context.getArgument("bool", Boolean.class)) {
                    module.toggle();
                }
            }
            return SINGLE_SUCCESS;
        }))));
    }
}
