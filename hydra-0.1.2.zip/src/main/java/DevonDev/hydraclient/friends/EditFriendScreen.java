

package DevonDev.hydraclient.friends;

import DevonDev.hydraclient.gui.screens.WindowScreen;

public class EditFriendScreen extends WindowScreen {
    public EditFriendScreen(Friend friend) {
        super(friend.name, true);
    }
}
