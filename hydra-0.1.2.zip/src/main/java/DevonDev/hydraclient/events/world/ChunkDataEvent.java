

package DevonDev.hydraclient.events.world;

import net.minecraft.world.chunk.WorldChunk;

public class ChunkDataEvent {
    public WorldChunk chunk;
}
