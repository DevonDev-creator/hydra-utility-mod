package DevonDev.hydraclient.events.world;

public class AmbientOcclusionEvent {
    public float lightLevel = -1;
}
