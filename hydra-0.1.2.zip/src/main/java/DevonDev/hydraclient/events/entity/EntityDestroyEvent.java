

package DevonDev.hydraclient.events.entity;

import net.minecraft.entity.Entity;

public class EntityDestroyEvent {
    public Entity entity;
}
