

package DevonDev.hydraclient.events.entity.player;

import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;

public class PlaceBlockEvent {
    public BlockPos blockPos;
    public Block block;
}
