

package DevonDev.hydraclient.events.entity.player;

public class SendMessageEvent {
    public String msg;
}
