

package DevonDev.hydraclient.events.render;

public class RenderEvent {
    public float tickDelta;
    public double offsetX, offsetY, offsetZ;
}
