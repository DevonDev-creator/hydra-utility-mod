package DevonDev.hydraclient.events.render;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.block.entity.BlockEntity;

public class RenderBlockEntityEvent extends Cancellable {
    public BlockEntity blockEntity;
}
