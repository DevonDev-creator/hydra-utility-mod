

package DevonDev.hydraclient.events.hydra;

public class MacroListChangedEvent {
}
