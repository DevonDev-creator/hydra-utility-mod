

package DevonDev.hydraclient.events.hydra;

import DevonDev.hydraclient.events.Cancellable;
import DevonDev.hydraclient.utils.KeyAction;

public class KeyEvent extends Cancellable {
    public int key;
    public KeyAction action;
}
