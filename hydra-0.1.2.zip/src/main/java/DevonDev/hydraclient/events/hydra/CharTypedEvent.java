

package DevonDev.hydraclient.events.hydra;

import DevonDev.hydraclient.events.Cancellable;

public class CharTypedEvent extends Cancellable {
    public char c;
}
