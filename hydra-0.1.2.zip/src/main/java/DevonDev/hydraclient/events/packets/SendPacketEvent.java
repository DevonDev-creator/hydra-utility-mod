

package DevonDev.hydraclient.events.packets;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.network.Packet;

public class SendPacketEvent extends Cancellable {
    public Packet<?> packet;
}
