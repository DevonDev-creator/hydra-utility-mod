

package DevonDev.hydraclient.events.game;

public class GameLeftEvent {
}
