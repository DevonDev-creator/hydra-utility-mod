

package DevonDev.hydraclient.mixininterface;

public interface ICloseHandledScreenC2SPacket {
    int getSyncId();
}
