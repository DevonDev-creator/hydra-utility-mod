

package DevonDev.hydraclient.mixininterface;

import net.minecraft.world.dimension.DimensionType;

public interface IDimensionType {
    DimensionType getNether();

    DimensionType getEnd();
}
