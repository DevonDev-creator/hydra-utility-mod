

package DevonDev.hydraclient.modules;

import DevonDev.hydraclient.Config;
import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.events.EventStore;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.Chat;
import DevonDev.hydraclient.utils.Utils;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Formatting;

public abstract class ToggleModule extends Module {
    private boolean active;
    private boolean visible = true;

    public ToggleModule(Category category, String name, String description) {
        super(category, name, description);
    }

    public void onActivate() {}
    public void onDeactivate() {}

    public void toggle(boolean onActivateDeactivate) {
        if (!active) {
            active = true;
            ModuleManager.INSTANCE.addActive(this);

            for (SettingGroup sg : settings) {
                for (Setting setting : sg) {
                    if (setting.onModuleActivated != null) setting.onModuleActivated.accept(setting);
                }
            }

            if (onActivateDeactivate) {
                HydraClient.EVENT_BUS.subscribe(this);
                onActivate();
            }
        }
        else {
            active = false;
            ModuleManager.INSTANCE.removeActive(this);

            if (onActivateDeactivate) {
                HydraClient.EVENT_BUS.unsubscribe(this);
                onDeactivate();
            }
        }
    }
    public void toggle() {
        toggle(true);
    }

    @Override
    public void doAction(boolean onActivateDeactivate) {
        toggle(onActivateDeactivate);
    }

    public String getInfoString() {
        return null;
    }

    @Override
    public CompoundTag toTag() {
        CompoundTag tag = super.toTag();

        tag.putBoolean("active", active);
        tag.putBoolean("visible", visible);

        return tag;
    }

    @Override
    public ToggleModule fromTag(CompoundTag tag) {
        super.fromTag(tag);

        boolean active = tag.getBoolean("active");
        if (active != isActive()) toggle(Utils.canUpdate());
        setVisible(tag.getBoolean("visible"));

        return this;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
        HydraClient.EVENT_BUS.post(EventStore.moduleVisibilityChangedEvent(this));
    }

    public boolean isVisible() {
        return visible;
    }

    public boolean isActive() {
        return active;
    }

    public void sendToggledMsg() {
        if (Config.INSTANCE.chatCommandsInfo) Chat.info("Toggled (highlight)%s(default) %s(default).", title, isActive() ? Formatting.GREEN + "on" : Formatting.RED + "off");
    }
}
