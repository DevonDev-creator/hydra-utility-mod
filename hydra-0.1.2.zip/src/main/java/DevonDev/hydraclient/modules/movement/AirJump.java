

package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.packets.SendPacketEvent;
import DevonDev.hydraclient.mixininterface.IPlayerMoveC2SPacket;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.hydra.KeyEvent;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.modules.render.Freecam;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.KeyAction;
import net.minecraft.block.*;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;

public class AirJump extends ToggleModule {
    public AirJump() {
        super(Category.Movement, "air-jump", "Lets you jump in the air.");
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> maintainY = sgGeneral.add(new BoolSetting.Builder()
            .name("maintain-level")
            .description("Maintains your current Y level")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> onHold = sgGeneral.add(new BoolSetting.Builder()
            .name("on-hold")
            .description("Whether or not to air jump if you hold down the space bar.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> groundSpoof = sgGeneral.add(new BoolSetting.Builder()
            .name("spoof-ground")
            .description("Whether or not to spoof onground state, helps bypass spartan and matrix.")
            .defaultValue(true)
            .build()
    );

    private int level = 0;
    private long jumpTime;

    @EventHandler
    private final Listener<SendPacketEvent> onSendPacket = new Listener<>(event -> {
        if (event.packet instanceof PlayerMoveC2SPacket) {
            if(System.currentTimeMillis() - jumpTime < 75) {
                if(mc.world.getBlockState(mc.player.getBlockPos().down()).getMaterial() == Material.AIR) {
                    ((IPlayerMoveC2SPacket) event.packet).setOnGround(true);
                }
            }
        }
    });

    @EventHandler
    private final Listener<KeyEvent> onKey = new Listener<>(event -> {
        if (ModuleManager.INSTANCE.isActive(Freecam.class) || mc.currentScreen != null) return;
        if ((event.action == KeyAction.Press || (event.action == KeyAction.Repeat && onHold.get())) && mc.options.keyJump.matchesKey(event.key, 0)) {
            jumpTime = System.currentTimeMillis();
            mc.player.jump();
            level = mc.player.getBlockPos().getY();
        }
        if ((event.action == KeyAction.Press || (event.action == KeyAction.Repeat && onHold.get())) && mc.options.keySneak.matchesKey(event.key, 0)){
            level -= 1;
        }
    });

    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (ModuleManager.INSTANCE.isActive(Freecam.class)) return;
        if (maintainY.get() && mc.player.getBlockPos().getY() == level){
            jumpTime = System.currentTimeMillis();
            mc.player.jump();
        }
    });
}
