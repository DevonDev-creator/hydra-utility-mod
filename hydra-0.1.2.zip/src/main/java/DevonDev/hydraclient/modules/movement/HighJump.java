

package DevonDev.hydraclient.modules.movement;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.entity.player.JumpVelocityMultiplierEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;

public class HighJump extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    
    private final Setting<Double> multiplier = sgGeneral.add(new DoubleSetting.Builder()
            .name("multiplier")
            .description("Jump height multiplier.")
            .defaultValue(1)
            .min(0)
            .build()
    );

    public HighJump() {
        super(Category.Movement, "high-jump", "Makes you jump higher than normal.");
    }

    @EventHandler
    private final Listener<JumpVelocityMultiplierEvent> onJumpVelocityMultiplier = new Listener<>(event -> {
        event.multiplier *= multiplier.get();
    });
}
