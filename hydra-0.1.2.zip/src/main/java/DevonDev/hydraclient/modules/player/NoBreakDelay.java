

package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class NoBreakDelay extends ToggleModule {
    public NoBreakDelay() {
        super(Category.Player, "no-break-delay", "Completely removes the delay between breaking blocks.");
    }
}