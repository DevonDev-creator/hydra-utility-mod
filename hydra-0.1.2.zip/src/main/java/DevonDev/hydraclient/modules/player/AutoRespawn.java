

package DevonDev.hydraclient.modules.player;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.game.OpenScreenEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends ToggleModule {
    public AutoRespawn() {
        super(Category.Player, "auto-respawn", "Automatically respawns after death.");
    }

    @EventHandler
    private final Listener<OpenScreenEvent> onOpenScreenEvent = new Listener<>(event -> {
        if (!(event.screen instanceof DeathScreen)) return;

        mc.player.requestRespawn();
        event.cancel();
    });
}
