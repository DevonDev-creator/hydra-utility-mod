

package DevonDev.hydraclient.modules.render;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.IntSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;

public class CustomFOV extends ToggleModule {
    private final SettingGroup sgGeneral = settings.createGroup("General");

    private final Setting<Integer> fov = sgGeneral.add(new IntSetting.Builder()
            .name("fov")
            .description("Your custom FOV.")
            .defaultValue(100)
            .sliderMin(1)
            .sliderMax(179)
            .build()
    );

    private float _fov;

    @Override
    public void onActivate() {
        _fov = (float) mc.options.fov;
        mc.options.fov = fov.get();
    }


    public void getFOV() {
        mc.options.fov = fov.get();
    }

    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (fov.get() != mc.options.fov) {
            getFOV();
        }
    });

    @Override
    public void onDeactivate() {
     mc.options.fov = _fov;
    }

    public CustomFOV() {
        super(Category.Render, "custom-fov", "Makes your FOV more customizable.");
    }

}
