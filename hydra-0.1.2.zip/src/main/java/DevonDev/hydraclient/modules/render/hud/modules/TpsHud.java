

package DevonDev.hydraclient.modules.render.hud.modules;

import DevonDev.hydraclient.modules.render.hud.HUD;
import DevonDev.hydraclient.utils.TickRate;

public class TpsHud extends DoubleTextHudModule {
    public TpsHud(HUD hud) {
        super(hud, "tps", "Displays the server's TPS.", "Tps: ");
    }

    @Override
    protected String getRight() {
        return String.format("%.1f", TickRate.INSTANCE.getTickRate());
    }
}
