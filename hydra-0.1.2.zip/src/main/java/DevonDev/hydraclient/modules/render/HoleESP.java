

package DevonDev.hydraclient.modules.render;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.render.RenderEvent;
import DevonDev.hydraclient.events.world.PreTickEvent;
import DevonDev.hydraclient.mixin.AbstractBlockAccessor;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.rendering.DrawMode;
import DevonDev.hydraclient.rendering.MeshBuilder;
import DevonDev.hydraclient.rendering.Renderer;
import DevonDev.hydraclient.rendering.ShapeMode;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.BlockIterator;
import DevonDev.hydraclient.utils.Color;
import DevonDev.hydraclient.utils.Pool;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class HoleESP extends ToggleModule {
    public enum Mode {
        Flat,
        Box,
        BoxBelow,
        Glow
    }

    private static final MeshBuilder MB;

    static {
        MB = new MeshBuilder(1024);
        MB.depthTest = true;
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgColors = settings.createGroup("Colors");

    private final Setting<Mode> renderMode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("render-mode")
            .description("The rendering mode.")
            .defaultValue(Mode.Glow)
            .build()
    );

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Lines)
            .build()
    );

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("horizontal-radius")
            .description("Horizontal radius in which to search for holes.")
            .defaultValue(10)
            .min(0)
            .sliderMax(32)
            .build()
    );

    private final Setting<Integer> verticalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("vertical-radius")
            .description("Vertical radius in which to search for holes.")
            .defaultValue(10)
            .min(0)
            .sliderMax(32)
            .build()
    );

    private final Setting<Integer> holeHeight = sgGeneral.add(new IntSetting.Builder()
            .name("hole-height")
            .description("Minimum hole height required to be rendered.")
            .defaultValue(3)
            .min(1)
            .build()
    );

    private final Setting<Double> glowHeight = sgGeneral.add(new DoubleSetting.Builder()
            .name("glow-height")
            .description("The height of the glow when Glow mode is active")
            .defaultValue(3)
            .min(1)
            .build()
    );

    private final Setting<Boolean> ignoreOwn = sgColors.add(new BoolSetting.Builder()
            .name("ignore-own")
            .description("Ignores rendering the hole you are currently standing in.")
            .defaultValue(true)
            .build()
    );


    private final Setting<Color> allBedrock = sgColors.add(new ColorSetting.Builder()
            .name("all-bedrock")
            .description("All blocks are bedrock.")
            .defaultValue(new Color(25, 225, 25))
            .build()
    );

    private final Setting<Color> someObsidian = sgColors.add(new ColorSetting.Builder()
            .name("some-obsidian")
            .description("Some blocks are obsidian.")
            .defaultValue(new Color(225, 145, 25))
            .build()
    );

    private final Setting<Color> allObsidian = sgColors.add(new ColorSetting.Builder()
            .name("all-obsidian")
            .description("All blocks are obsidian.")
            .defaultValue(new Color(225, 25, 25))
            .build()
    );

    private final Pool<Hole> holePool = new Pool<>(Hole::new);
    private final BlockPos.Mutable blockPos = new BlockPos.Mutable();
    private final List<Hole> holes = new ArrayList<>();
    private final Color transparent = new Color(0, 0, 0, 0);

    public HoleESP() {
        super(Category.Render, "hole-esp", "Displays safe holes that you will take less damage in.");
    }

    @EventHandler
    private final Listener<PreTickEvent> onTick = new Listener<>(event -> {
        for (Hole hole : holes) holePool.free(hole);
        holes.clear();

        BlockIterator.register(horizontalRadius.get(), verticalRadius.get(), (blockPos1, blockState) -> {
            blockPos.set(blockPos1);

            if (!checkHeight()) return;
            if (ignoreOwn.get() && (mc.player.getBlockPos().equals(blockPos))) return;

            Block bottom = mc.world.getBlockState(add(0, -1, 0)).getBlock();
            if (bottom != Blocks.BEDROCK && bottom != Blocks.OBSIDIAN) return;
            Block forward = mc.world.getBlockState(add(0, 1, 1)).getBlock();
            if (forward != Blocks.BEDROCK && forward != Blocks.OBSIDIAN) return;
            Block back = mc.world.getBlockState(add(0, 0, -2)).getBlock();
            if (back != Blocks.BEDROCK && back != Blocks.OBSIDIAN) return;
            Block right = mc.world.getBlockState(add(1, 0, 1)).getBlock();
            if (right != Blocks.BEDROCK && right != Blocks.OBSIDIAN) return;
            Block left = mc.world.getBlockState(add(-2, 0, 0)).getBlock();
            if (left != Blocks.BEDROCK && left != Blocks.OBSIDIAN) return;
            add(1, 0, 0);

            if (bottom == Blocks.BEDROCK && forward == Blocks.BEDROCK && back == Blocks.BEDROCK && right == Blocks.BEDROCK && left == Blocks.BEDROCK) {
                holes.add(holePool.get().set(blockPos, allBedrock.get()));
            } else {
                int obsidian = 0;

                if (bottom == Blocks.OBSIDIAN) obsidian++;
                if (forward == Blocks.OBSIDIAN) obsidian++;
                if (back == Blocks.OBSIDIAN) obsidian++;
                if (right == Blocks.OBSIDIAN) obsidian++;
                if (left == Blocks.OBSIDIAN) obsidian++;

                if (obsidian == 5) holes.add(holePool.get().set(blockPos, allObsidian.get()));
                else holes.add(holePool.get().set(blockPos, someObsidian.get()));
            }
        });
    });

    private boolean checkHeight() {
        if (((AbstractBlockAccessor) mc.world.getBlockState(blockPos).getBlock()).isCollidable()) return false;

        for (int i = 0; i < holeHeight.get() - 1; i++) {
            if (((AbstractBlockAccessor) mc.world.getBlockState(add(0, 1, 0)).getBlock()).isCollidable()) return false;
        }

        add(0, -holeHeight.get() + 1, 0);
        return true;
    }

    @EventHandler
    private final Listener<RenderEvent> onRender = new Listener<>(event -> {
        if (renderMode.get() == Mode.Glow) {
            MB.begin(event, DrawMode.Triangles, VertexFormats.POSITION_COLOR);
        }

        for (Hole hole : holes) {
            int x = hole.blockPos.getX();
            int y = hole.blockPos.getY();
            int z = hole.blockPos.getZ();

            switch (renderMode.get()) {
                case Flat:
                    Renderer.quadWithLinesHorizontal(Renderer.NORMAL, Renderer.LINES, x, y, z, 1, hole.colorSides, hole.colorLines, shapeMode.get());
                    break;
                case Box:
                    Renderer.boxWithLines(Renderer.NORMAL, Renderer.LINES, x, y, z, 1, hole.colorSides, hole.colorLines, shapeMode.get(), 0);
                    break;
                case BoxBelow:
                    Renderer.boxWithLines(Renderer.NORMAL, Renderer.LINES, x, y - 1, z, 1, hole.colorSides, hole.colorLines, shapeMode.get(), 0);
                    break;
                case Glow:
                    Renderer.quadWithLinesHorizontal(Renderer.NORMAL, Renderer.LINES, x, y, z, 1, hole.colorSides, hole.colorLines, shapeMode.get());
                    MB.gradientBoxSides(x, y, z, x + 1, y + glowHeight.get(), z + 1, hole.colorSides, transparent);
                    break;
            }
        }

        if (renderMode.get() == Mode.Glow) {
            MB.end();
        }
    });

    private BlockPos.Mutable add(int x, int y, int z) {
        blockPos.setX(blockPos.getX() + x);
        blockPos.setY(blockPos.getY() + y);
        blockPos.setZ(blockPos.getZ() + z);

        return blockPos;
    }

    private static class Hole {
        public BlockPos.Mutable blockPos = new BlockPos.Mutable();
        public Color colorSides = new Color();
        public Color colorLines = new Color();

        public Hole set(BlockPos blockPos, Color color) {
            this.blockPos.set(blockPos);

            colorLines.set(color);
            colorSides.set(color);
            colorSides.a -= 175;
            colorSides.validate();

            return this;
        }
    }
}