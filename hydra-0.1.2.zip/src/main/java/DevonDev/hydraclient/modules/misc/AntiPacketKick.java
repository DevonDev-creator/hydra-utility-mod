

package DevonDev.hydraclient.modules.misc;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class AntiPacketKick extends ToggleModule {
    public AntiPacketKick() {
        super(Category.Misc, "anti-packet-kick", "Attempts to prevent you from being disconnected by large packets.");
    }
}
