

package DevonDev.hydraclient.modules;

public enum Category {
    Combat,
    Player,
    Movement,
    Render,
    Misc
}
