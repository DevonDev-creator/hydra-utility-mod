

package DevonDev.hydraclient.modules.combat;

//Created by squidoodly 16/07/2020 (Yay! Empty class!!!)

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.entity.player.AttackEntityEvent;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import net.minecraft.entity.player.PlayerEntity;

public class AntiFriendHit extends ToggleModule {
    public AntiFriendHit() {
        super(Category.Combat, "anti-friend-hit", "Cancels out attacks that would hit friends.");
    }

    @EventHandler
    private final Listener<AttackEntityEvent> onAttackEntity = new Listener<>(event -> {
        if (event.entity instanceof PlayerEntity &&  ModuleManager.INSTANCE.get(AntiFriendHit.class).isActive() && !FriendManager.INSTANCE.attack((PlayerEntity) event.entity)) event.cancel();
    });
}
