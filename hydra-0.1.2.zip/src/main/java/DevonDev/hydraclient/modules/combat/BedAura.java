

package DevonDev.hydraclient.modules.combat;

//Created by squidoodly 03/06/2020
//Updated by squidoodly 19/06/2020

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.modules.player.FakePlayer;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.*;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BedItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Collectors;

public class BedAura extends ToggleModule {
    public enum Mode{
        safe,
        suicide
    }

    public BedAura(){
        super(Category.Combat, "bed-aura", "Automatically places and explodes beds in the Nether and End.");
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgPlace = settings.createGroup("Place");

    private final Setting<Double> placeRange = sgGeneral.add(new DoubleSetting.Builder()
            .name("place-range")
            .description("The distance in a single direction the beds get placed.")
            .defaultValue(3)
            .min(0)
            .sliderMax(5)
            .build()
    );

    private final Setting<Double> breakRange = sgGeneral.add(new DoubleSetting.Builder()
            .name("break-range")
            .description("The distance in a single direction the beds get broken.")
            .defaultValue(3)
            .min(0)
            .sliderMax(5)
            .build()
    );

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("place-mode")
            .description("How beds get placed.")
            .defaultValue(Mode.safe)
            .build()
    );

    private final Setting<Boolean> selfToggle = sgGeneral.add(new BoolSetting.Builder()
            .name("self-toggle")
            .description("Toggles this in the overworld.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Mode> clickMode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("break-mode")
            .description("How beds are broken.")
            .defaultValue(Mode.safe)
            .build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
            .name("auto-switch")
            .description("Switches to a bed automatically.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> switchBack = sgGeneral.add(new BoolSetting.Builder()
            .name("switch-back")
            .description("Switches back to the previous slot after auto switching.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> autoMove = sgGeneral.add(new BoolSetting.Builder()
            .name("auto-move")
            .description("Moves beds into your last hotbar slot.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Integer> autoMoveSlot = sgGeneral.add(new IntSetting.Builder()
            .name("auto-move-slot")
            .description("The slot Auto Move moves beds to.")
            .defaultValue(8)
            .min(0)
            .max(8)
            .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("The delay between placements.")
            .defaultValue(2)
            .min(0)
            .sliderMax(10)
            .build()
    );

    private final Setting<Boolean> smartDelay = sgGeneral.add(new BoolSetting.Builder()
            .name("smart-delay")
            .description("Reduces bed consumption when doing large amounts of damage.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Double> healthDifference = sgGeneral.add(new DoubleSetting.Builder()
            .name("damage-increase")
            .description("The damage increase for smart delay to work.")
            .defaultValue(5)
            .min(0)
            .max(20)
            .build()
    );

    private final Setting<Boolean> airPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("air-place")
            .description("Places beds in the air if they do more damage.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Double> minDamage = sgPlace.add(new DoubleSetting.Builder()
            .name("min-damage")
            .description("The minimum damage the beds will place.")
            .defaultValue(5.5)
            .build()
    );

    private final Setting<Double> maxDamage = sgPlace.add(new DoubleSetting.Builder()
            .name("max-damage")
            .description("The maximum self-damage allowed.")
            .defaultValue(3)
            .build()
    );

    private final Setting<Double> minHealth = sgPlace.add(new DoubleSetting.Builder()
            .name("min-health")
            .description("The minimum health you have to be for it to place.")
            .defaultValue(15)
            .build()
    );

    private final Setting<Boolean> place = sgGeneral.add(new BoolSetting.Builder()
            .name("place")
            .description("Allows Bed Aura to place beds.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> calcDamage = sgGeneral.add(new BoolSetting.Builder()
            .name("damage-calc")
            .description("Whether to calculate damage (true) or just place on the head of the target (false).")
            .defaultValue(false)
            .build()
    );

    private int delayLeft = delay.get();
    private Vec3d bestBlock;
    private double bestDamage;
    private BlockPos playerPos;
    private double currentDamage;
    private BlockPos bestBlockPos;
    private BlockPos pos;
    private Vec3d vecPos;
    private BlockPos posUp;
    private float preYaw;
    private double lastDamage = 0;
    private int direction = 0;
    int preSlot = -1;
    boolean bypassCheck = false;

    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        delayLeft --;
        preSlot = -1;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() <= minHealth.get() && mode.get() != Mode.suicide) return;
        if (selfToggle.get() && mc.world.getDimension().isBedWorking()) {
            Chat.warning(this, "You are in the overworld. Disabling!");
            this.toggle();
            return;
        }
        try {
            for (BlockEntity entity : mc.world.blockEntities) {
                if (entity instanceof BedBlockEntity && Utils.distance(entity.getPos().getX(), entity.getPos().getY(), entity.getPos().getZ(), mc.player.getX(), mc.player.getY(), mc.player.getZ()) <= breakRange.get()) {
                    currentDamage = DamageCalcUtils.bedDamage(mc.player, Utils.vec3d(entity.getPos()));
                    if (currentDamage < maxDamage.get()
                            || (mc.player.getHealth() + mc.player.getAbsorptionAmount() - currentDamage) < minHealth.get() || clickMode.get().equals(Mode.suicide)) {
                        mc.player.setSneaking(false);
                        mc.interactionManager.interactBlock(mc.player, mc.world, Hand.MAIN_HAND, new BlockHitResult(mc.player.getPos(), Direction.UP, entity.getPos(), false));
                    }

                }
            }
        } catch (ConcurrentModificationException ignored) {
            return;
        }
        if (place.get() && (!(mc.player.getMainHandStack().getItem() instanceof BedItem)
                && !(mc.player.getOffHandStack().getItem() instanceof BedItem)) && !autoSwitch.get() && !autoMove.get()) return;
        if (place.get()) {
            boolean doMove = true;
            if (!(mc.player.getMainHandStack().getItem() instanceof BedItem)
                    && !(mc.player.getOffHandStack().getItem() instanceof BedItem)){
                if (autoMove.get()){
                    for (int i = 0; i < 9; i++) {
                        if (mc.player.inventory.getStack(i).getItem() instanceof BedItem) {
                            doMove = false;
                            break;
                        }
                    }
                    if (doMove){
                        int slot = -1;
                        for (int i = 0; i < mc.player.inventory.main.size(); i++){
                            ItemStack itemStack = mc.player.inventory.main.get(i);
                            if (itemStack.getItem() instanceof BedItem){
                                slot = i;
                            }
                        }
                        InvUtils.clickSlot(InvUtils.invIndexToSlotId(autoMoveSlot.get()), 0, SlotActionType.PICKUP);
                        InvUtils.clickSlot(InvUtils.invIndexToSlotId(slot), 0, SlotActionType.PICKUP);
                        InvUtils.clickSlot(InvUtils.invIndexToSlotId(autoMoveSlot.get()), 0, SlotActionType.PICKUP);
                    }
                }
                if (autoSwitch.get()){
                    for (int i = 0; i < 9; i++) {
                        if (mc.player.inventory.getStack(i).getItem() instanceof BedItem) {
                            preSlot = mc.player.inventory.selectedSlot;
                            mc.player.inventory.selectedSlot = i;
                            break;
                        }
                    }
                }

            }
            if (!(mc.player.getMainHandStack().getItem() instanceof BedItem)
                    && !(mc.player.getOffHandStack().getItem() instanceof BedItem)){
                return;
            }
            AbstractClientPlayerEntity target = null;
            for (Map.Entry<FakePlayerEntity, Integer> player : FakePlayer.players.entrySet()){
                if (target == null) {
                    target = player.getKey();
                } else if (mc.player.distanceTo(player.getKey()) < mc.player.distanceTo(target)){
                    target = player.getKey();
                }
            }
            if (target == null) {
                Iterator<AbstractClientPlayerEntity> validEntities = mc.world.getPlayers().stream()
                        .filter(FriendManager.INSTANCE::attack)
                        .filter(entityPlayer -> !entityPlayer.getDisplayName().equals(mc.player.getDisplayName()))
                        .filter(entityPlayer -> mc.player.distanceTo(entityPlayer) <= 10)
                        .filter(entityPlayer -> !entityPlayer.isCreative() && !entityPlayer.isSpectator())
                        .collect(Collectors.toList()).iterator();

                if (validEntities.hasNext()) {
                    target = validEntities.next();
                } else {
                    return;
                }
                for (AbstractClientPlayerEntity i = null; validEntities.hasNext(); i = validEntities.next()) {
                    if (i == null) continue;
                    if (mc.player.distanceTo(i) < mc.player.distanceTo(target)) {
                        target = i;
                    }
                }
            }
            if (target == null) return;
            if (!smartDelay.get() && delayLeft > 0) return;
            if (calcDamage.get()) {
                findValidBlocks(target);
            } else {
                findFacePlace(target);
            }
            if (bestBlock != null && (bestDamage >= minDamage.get() || bypassCheck)) {
                bypassCheck = false;
                if (!smartDelay.get()) {
                    delayLeft = delay.get();
                    placeBlock();
                }else if (smartDelay.get() && (delayLeft <= 0 || bestDamage - lastDamage > healthDifference.get())) {
                    lastDamage = bestDamage;
                    placeBlock();
                    if (delayLeft <= 0) delayLeft = 10;
                }
            }
        }
    });

    private void placeBlock(){
        bestBlockPos = new BlockPos(bestBlock.x, bestBlock.y, bestBlock.z);
        Hand hand = Hand.MAIN_HAND;
        if (!(mc.player.getMainHandStack().getItem() instanceof BedItem) && mc.player.getOffHandStack().getItem() instanceof BedItem) {
            hand = Hand.OFF_HAND;
        }
        preYaw = mc.player.yaw;
        if (direction == 0) {
            mc.player.yaw = -90f;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookOnly(-90f, mc.player.pitch, mc.player.isOnGround()));
        } else if (direction == 1) {
            mc.player.yaw = 179f;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookOnly(179f, mc.player.pitch, mc.player.isOnGround()));
        } else if (direction == 2) {
            mc.player.yaw = 1f;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookOnly(1f, mc.player.pitch, mc.player.isOnGround()));
        } else if (direction == 3) {
            mc.player.yaw = 90f;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookOnly(90f, mc.player.pitch, mc.player.isOnGround()));
        }
        mc.player.yaw = preYaw;
        lastDamage = bestDamage;
        mc.interactionManager.interactBlock(mc.player, mc.world, hand, new BlockHitResult(mc.player.getPos(), Direction.UP, bestBlockPos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (preSlot != -1 && mc.player.inventory.selectedSlot != preSlot && switchBack.get()) {
            mc.player.inventory.selectedSlot = preSlot;
        }
    }

    private void findValidBlocks(PlayerEntity target){
        assert mc.world != null;
        assert mc.player != null;
        bestBlock = null;
        bestDamage = 0;
        playerPos = mc.player.getBlockPos();
        for(double i = playerPos.getX() - placeRange.get(); i < playerPos.getX() + placeRange.get(); i++){
            for(double j = playerPos.getZ() - placeRange.get(); j < playerPos.getZ() + placeRange.get(); j++){
                for(double k = playerPos.getY() - 3; k < playerPos.getY() + 3; k++) {
                    pos = new BlockPos(i, j, k);
                    vecPos = new Vec3d(Math.floor(i), Math.floor(k), Math.floor(j));
                    posUp = pos.add(0, 1, 0);
                    if (bestBlock == null) bestBlock = vecPos;
                    if (isValid(posUp)) {
                        if (airPlace.get() || !mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
                            if (bestDamage < DamageCalcUtils.bedDamage(target, vecPos.add(0.5, 1.5, 0.5))
                                    && (DamageCalcUtils.bedDamage(mc.player, vecPos.add(0.5, 1.5, 0.5)) < minDamage.get() || mode.get() == Mode.suicide)) {
                                bestBlock = vecPos;
                                bestDamage = DamageCalcUtils.bedDamage(target, bestBlock.add(0.5, 1.5, 0.5));
                            }
                        }
                    }
                }
            }
        }
        if (bestBlock == null) return;
        double north, east, south, west;
        bestBlockPos = new BlockPos(bestBlock.x, bestBlock.y, bestBlock.z);
        east = DamageCalcUtils.bedDamage(target, bestBlock.add(1.5, 1.5, 0.5));
        west = DamageCalcUtils.bedDamage(target, bestBlock.add(-1.5, 1.5, 0.5));
        south = DamageCalcUtils.bedDamage(target, bestBlock.add(0.5, 1.5, 1.5));
        north = DamageCalcUtils.bedDamage(target, bestBlock.add(0.5, 1.5, -1.5));

        if ((east > north) && (east > south) && (east > west)) {
            direction = 0;
        } else if ((east < north) && (north > south) && (north > west)) {
            direction = 1;
        } else if ((south > north) && (east < south) && (south > west)) {
            direction = 2;
        } else if ((west > north) && (west > south) && (east < west)) {
            direction = 3;
        }
        bestDamage = Math.max(bestDamage, Math.max(north, Math.max(east, Math.max(south, west))));
    }

    private void findFacePlace(PlayerEntity target) {
        assert mc.world != null;
        assert mc.player != null;
        if (mc.player.distanceTo(target) < placeRange.get() && mc.world.isAir(target.getBlockPos().add(0, 1, 0))) {
            if (isValidHalf(target.getBlockPos().add(1, 0, 0))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 1.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 0.5);
                direction = 3;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(-1, 0, 0))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() - 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 0.5);
                direction = 0;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(0, 0, 1))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 1.5);
                direction = 1;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(0, 0, -1))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() - 0.5);
                direction = 2;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(1, 1, 0))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 1.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 0.5);
                direction = 3;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(-1, 1, 0))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() - 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 0.5);
                direction = 0;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(0, 1, 1))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() + 1.5);
                direction = 1;
                bypassCheck = true;
            } else if (isValidHalf(target.getBlockPos().add(0, 1, -1))) {
                bestBlock = new Vec3d(target.getBlockPos().getX() + 0.5, target.getBlockPos().getY() + 1, target.getBlockPos().getZ() - 0.5);
                direction = 2;
                bypassCheck = true;
            }
        }
    }

    private boolean isValidHalf(BlockPos pos) {
        assert mc.world != null;
        return (airPlace.get() || mc.world.isAir(pos)) && mc.world.isAir(pos.up());
    }

    private boolean isValid(BlockPos posUp) {
        return (mc.world.getBlockState(posUp).getMaterial().isReplaceable())
                && mc.world.getOtherEntities(null, new Box(posUp.getX(), posUp.getY(), posUp.getZ(), posUp.getX() + 1.0D, posUp.getY() + 1.0D, posUp.getZ() + 1.0D)).isEmpty()
                && (mc.world.getBlockState(new BlockPos(posUp).add(1, 0, 0)).getMaterial().isReplaceable() || mc.world.getBlockState(posUp.add(-1, 0, 0)).getMaterial().isReplaceable()
                || mc.world.getBlockState(posUp.add(0, 0, 1)).getMaterial().isReplaceable() || mc.world.getBlockState(posUp.add(0, 0, -1)).getMaterial().isReplaceable());
    }
}
