package DevonDev.hydraclient.mixin;

import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.events.world.AmbientOcclusionEvent;
import DevonDev.hydraclient.events.EventStore;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractBlock.class)
public class AbstractBlockMixin {
    @Inject(method = "getAmbientOcclusionLightLevel", at = @At("HEAD"), cancellable = true)
    private void onGetAmbientOcclusionLightLevel(BlockState state, BlockView world, BlockPos pos, CallbackInfoReturnable<Float> info) {
        AmbientOcclusionEvent event = HydraClient.postEvent(EventStore.ambientOcclusionEvent());
        if (event.lightLevel != -1) info.setReturnValue(event.lightLevel);
    }
}
