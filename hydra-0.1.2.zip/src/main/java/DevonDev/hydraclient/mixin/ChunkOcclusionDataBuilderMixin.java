

package DevonDev.hydraclient.mixin;

import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.events.world.ChunkOcclusionEvent;
import DevonDev.hydraclient.events.EventStore;
import net.minecraft.client.render.chunk.ChunkOcclusionDataBuilder;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkOcclusionDataBuilder.class)
public class ChunkOcclusionDataBuilderMixin {
    @Inject(method = "markClosed", at = @At("HEAD"), cancellable = true)
    private void onMarkClosed(BlockPos pos, CallbackInfo info) {
        ChunkOcclusionEvent event = HydraClient.postEvent(EventStore.chunkOcclusionEvent());
        if (event.isCancelled()) info.cancel();
    }
}
