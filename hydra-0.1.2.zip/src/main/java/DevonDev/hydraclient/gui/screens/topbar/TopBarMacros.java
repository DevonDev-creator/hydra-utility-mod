package DevonDev.hydraclient.gui.screens.topbar;

import DevonDev.hydraclient.events.hydra.MacroListChangedEvent;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.gui.widgets.WMinus;
import DevonDev.hydraclient.gui.widgets.WTable;
import DevonDev.hydraclient.macros.EditMacroScreen;
import DevonDev.hydraclient.macros.Macro;
import DevonDev.hydraclient.macros.MacroManager;
import DevonDev.hydraclient.utils.Utils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.MinecraftClient;

public class TopBarMacros extends TopBarWindowScreen {
    @EventHandler
    private final Listener<MacroListChangedEvent> onMacroListChanged = new Listener<>(event -> {
        clear();
        initWidgets();
    });

    public TopBarMacros() {
        super(TopBarType.Macros);
    }

    @Override
    protected void initWidgets() {
        // Macros
        if (MacroManager.INSTANCE.getAll().size() > 0) {
            WTable t = add(new WTable()).getWidget();

            for (Macro macro : MacroManager.INSTANCE) {
                t.add(new WLabel(macro.name + " (" + Utils.getKeyName(macro.key) + ")"));

                WButton edit = t.add(new WButton(WButton.ButtonRegion.Edit)).getWidget();
                edit.action = () -> MinecraftClient.getInstance().openScreen(new EditMacroScreen(macro));

                WMinus remove = t.add(new WMinus()).getWidget();
                remove.action = () -> MacroManager.INSTANCE.remove(macro);
            }

            row();
        }

        // Create macro
        WButton create = add(new WButton("Create")).fillX().expandX().getWidget();
        create.action = () -> MinecraftClient.getInstance().openScreen(new EditMacroScreen(null));
    }
}
