package DevonDev.hydraclient.gui.screens.topbar;

import DevonDev.hydraclient.gui.widgets.Cell;
import DevonDev.hydraclient.gui.widgets.WWidget;
import DevonDev.hydraclient.gui.widgets.WWindow;

public abstract class TopBarWindowScreen extends TopBarScreen {
    private final WWindow window;

    public TopBarWindowScreen(TopBarType type) {
        super(type);

        window = super.add(new WWindow(type.toString(), true)).centerXY().getWidget();

        addTopBar();
        initWidgets();
    }

    protected abstract void initWidgets();

    @Override
    public <T extends WWidget> Cell<T> add(T widget) {
        return window.add(widget);
    }

    protected void row() {
        window.row();
    }

    @Override
    public void clear() {
        window.clear();
    }
}
