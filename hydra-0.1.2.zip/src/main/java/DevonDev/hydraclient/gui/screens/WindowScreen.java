package DevonDev.hydraclient.gui.screens;

import DevonDev.hydraclient.gui.WidgetScreen;
import DevonDev.hydraclient.gui.widgets.Cell;
import DevonDev.hydraclient.gui.widgets.WWidget;
import DevonDev.hydraclient.gui.widgets.WWindow;

public abstract class WindowScreen extends WidgetScreen {
    private final WWindow window;

    public WindowScreen(String title, boolean expanded) {
        super(title);

        window = super.add(new WWindow(title, expanded)).centerXY().getWidget();
    }

    @Override
    public <T extends WWidget> Cell<T> add(T widget) {
        return window.add(widget);
    }

    public void row() {
        window.row();
    }

    @Override
    public void clear() {
        window.clear();
    }
}
