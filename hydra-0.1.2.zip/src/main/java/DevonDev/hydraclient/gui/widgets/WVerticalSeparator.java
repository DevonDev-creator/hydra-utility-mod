package DevonDev.hydraclient.gui.widgets;

import DevonDev.hydraclient.gui.GuiConfig;
import DevonDev.hydraclient.gui.renderer.GuiRenderer;
import DevonDev.hydraclient.gui.renderer.Region;

public class WVerticalSeparator extends WWidget {
    @Override
    protected void onCalculateSize(GuiRenderer renderer) {
        width = 1;
        height = 0;
    }

    @Override
    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        renderer.quad(Region.FULL, x, y, width, height, GuiConfig.INSTANCE.separator);
    }
}
