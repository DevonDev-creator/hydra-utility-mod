package DevonDev.hydraclient.gui.widgets;

import DevonDev.hydraclient.gui.GuiConfig;
import DevonDev.hydraclient.gui.renderer.GuiRenderer;
import DevonDev.hydraclient.utils.Color;

public class WTitle extends WWidget {
    private final String text;
    public Color color;

    public WTitle(String text) {
        this.text = text;

        this.color = GuiConfig.INSTANCE.text;
    }

    @Override
    protected void onCalculateSize(GuiRenderer renderer) {
        width = renderer.titleWidth(text);
        height = renderer.titleHeight();
    }

    @Override
    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        renderer.title(text, x, y, color);
    }
}
