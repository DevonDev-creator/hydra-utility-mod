package DevonDev.hydraclient.gui.screens;

import DevonDev.hydraclient.Config;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WHorizontalSeparator;
import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.gui.widgets.WTable;
import com.g00fy2.versioncompare.Version;
import net.minecraft.util.Util;

public class NewUpdateScreen extends WindowScreen {
    public NewUpdateScreen(Version latestVer) {
        super("New Update", true);

        add(new WLabel("New version of hydra has been released."));
        row();

        add(new WHorizontalSeparator());

        WTable versionsT = add(new WTable()).getWidget();
        versionsT.add(new WLabel("Your version:"));
        versionsT.add(new WLabel(Config.INSTANCE.version.getOriginalString()));
        versionsT.row();
        versionsT.add(new WLabel("Latest version"));
        versionsT.add(new WLabel(latestVer.getOriginalString()));
        row();

        add(new WHorizontalSeparator());

        WTable buttonsT = add(new WTable()).getWidget();
        buttonsT.add(new WButton("Download " + latestVer.getOriginalString())).fillX().expandX().getWidget().action = () -> Util.getOperatingSystem().open("https://hydraclient.com/");
        buttonsT.add(new WButton("OK")).fillX().expandX().getWidget().action = this::onClose;
    }
}
