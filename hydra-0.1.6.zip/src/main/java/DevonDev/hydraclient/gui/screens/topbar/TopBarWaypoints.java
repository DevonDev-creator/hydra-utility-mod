package DevonDev.hydraclient.gui.screens.topbar;

import DevonDev.hydraclient.events.hydra.WaypointListChangedEvent;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.utils.Utils;
import DevonDev.hydraclient.waypoints.Waypoint;
import DevonDev.hydraclient.waypoints.Waypoints;
import DevonDev.hydraclient.waypoints.gui.EditWaypointScreen;
import DevonDev.hydraclient.waypoints.gui.WWaypoint;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.MinecraftClient;

public class TopBarWaypoints extends TopBarWindowScreen {
    @EventHandler
    private final Listener<WaypointListChangedEvent> onWaypointListChanged = new Listener<>(event -> {
        clear();
        initWidgets();
    });

    public TopBarWaypoints() {
        super(TopBarType.Waypoints);
    }

    @Override
    protected void initWidgets() {
        // Waypoints
        for (Waypoint waypoint : Waypoints.INSTANCE) {
            add(new WWaypoint(waypoint)).fillX().expandX();
            row();
        }

        // Add
        if (Utils.canUpdate()) {
            WButton add = add(new WButton("Add")).fillX().expandX().getWidget();
            add.action = () -> MinecraftClient.getInstance().openScreen(new EditWaypointScreen(null));
        }
    }
}
