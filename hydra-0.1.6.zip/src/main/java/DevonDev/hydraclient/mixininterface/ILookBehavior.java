

package DevonDev.hydraclient.mixininterface;

import baritone.api.utils.Rotation;

public interface ILookBehavior {
    Rotation getTarget();
}
