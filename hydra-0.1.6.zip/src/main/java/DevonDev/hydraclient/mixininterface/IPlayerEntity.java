

package DevonDev.hydraclient.mixininterface;

import net.minecraft.entity.player.PlayerInventory;

public interface IPlayerEntity {
    void setInventory(PlayerInventory inventory);
}
