

package DevonDev.hydraclient.mixininterface;

public interface IBufferBuilder {
    boolean isBuilding();
}
