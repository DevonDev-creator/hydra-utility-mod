

package DevonDev.hydraclient.mixininterface;

public interface IPlayerMoveC2SPacket {
    void setY(double y);
    void setOnGround(boolean onGround);
    void setYaw(float yaw);
    void setPitch(float pitch);
}
