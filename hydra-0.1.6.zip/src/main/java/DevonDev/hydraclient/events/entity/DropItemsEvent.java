package DevonDev.hydraclient.events.entity;

import net.minecraft.item.ItemStack;

public class DropItemsEvent {
    public ItemStack itemStack;
}
