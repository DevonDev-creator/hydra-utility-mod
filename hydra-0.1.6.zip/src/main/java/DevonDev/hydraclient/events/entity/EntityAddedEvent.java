package DevonDev.hydraclient.events.entity;

import net.minecraft.entity.Entity;

public class EntityAddedEvent {
    public Entity entity;
}
