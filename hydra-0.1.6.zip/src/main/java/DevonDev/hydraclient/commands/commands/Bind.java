package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.commands.arguments.ModuleArgumentType;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.utils.Chat;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Bind extends Command {
    public Bind() {
        super("bind", "Binds a module to a specified key.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("module", ModuleArgumentType.module())
                .executes(context -> {
                    Module m = context.getArgument("module", Module.class);

                    Chat.info("Press a key you want this module to be bound to.");
                    ModuleManager.INSTANCE.setModuleToBind(m);

                    return SINGLE_SUCCESS;
                }));
    }
}
