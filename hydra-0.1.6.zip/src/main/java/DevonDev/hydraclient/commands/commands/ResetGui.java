package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.Config;
import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.utils.Chat;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class ResetGui extends Command {
    public ResetGui() {
        super("reset-gui", "Resets ClickGUI positions.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            Config.INSTANCE.guiConfig.clearWindowConfigs();
            Chat.info("The ClickGUI positioning has been reset.");

            return SINGLE_SUCCESS;
        });
    }
}
