package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.commands.arguments.ModuleArgumentType;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.settings.Setting;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Reset extends Command {
    public Reset() {
        super("reset", "Resets to the module's old settings.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("module", ModuleArgumentType.module())
                .executes(context -> {
                    Module module = context.getArgument("module", Module.class);
                    module.settings.forEach(group -> group.forEach(Setting::reset));
                    return SINGLE_SUCCESS;
                }));
    }
}
