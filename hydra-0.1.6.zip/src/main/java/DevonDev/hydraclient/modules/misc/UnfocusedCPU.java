package DevonDev.hydraclient.modules.misc;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class UnfocusedCPU extends ToggleModule {
    public UnfocusedCPU() {
        super(Category.Misc, "unfocused-CPU", "Will not render anything when your Minecraft window is not focused.");
    }
}
