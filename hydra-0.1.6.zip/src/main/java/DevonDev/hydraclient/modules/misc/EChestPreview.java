package DevonDev.hydraclient.modules.misc;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class EChestPreview extends ToggleModule {
    public EChestPreview() {
        super(Category.Misc, "EChest-preview", "Stores what's inside your Ender Chests and displays when you hover over it.");
    }
}
