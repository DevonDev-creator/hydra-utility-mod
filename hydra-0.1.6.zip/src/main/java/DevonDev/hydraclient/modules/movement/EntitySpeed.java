package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.entity.LivingEntityMoveEvent;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.mixininterface.IKeyBinding;
import DevonDev.hydraclient.mixininterface.IVec3d;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.PlayerUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class EntitySpeed extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
            .name("speed")
            .description("Horizontal speed in blocks per second.")
            .defaultValue(10)
            .min(0)
            .sliderMax(50)
            .build()
    );

    private final Setting<Boolean> onlyOnGround = sgGeneral.add(new BoolSetting.Builder()
            .name("only-on-ground")
            .description("Use speed only when standing on a block.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Double> remountInterval = sgGeneral.add(new DoubleSetting.Builder()
            .name("remount-interval")
            .description("Remounts the horse every so often to bypass anticheats, 0 = disabled.")
            .defaultValue(0)
            .min(0)
            .sliderMax(3000)
            .build()
    );

    private final Setting<Boolean> inWater = sgGeneral.add(new BoolSetting.Builder()
            .name("in-water")
            .description("Use speed when in water.")
            .defaultValue(false)
            .build()
    );
    private long lastRemount;
    private boolean doingRemount = false;
    private int remountTicks = 0;
    private Entity mount;


    @EventHandler
    private final Listener<LivingEntityMoveEvent> onLivingEntityMove = new Listener<>(event -> {
        if (event.entity.getPrimaryPassenger() != mc.player) return;

        // Check for onlyOnGround and inWater
        LivingEntity entity = event.entity;
        if (onlyOnGround.get() && !entity.isOnGround()) return;
        if (!inWater.get() && entity.isTouchingWater()) return;

        if(remountInterval.get() != 0){
           if(System.currentTimeMillis() - lastRemount > remountInterval.get()){
               doingRemount = true;
               mount = event.entity;
               mount.removeAllPassengers();
               mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.PRESS_SHIFT_KEY));
           }
        }

        // Set horizontal velocity
        Vec3d vel = PlayerUtils.getHorizontalVelocity(speed.get());
        ((IVec3d) event.movement).setXZ(vel.x, vel.z);
    });

    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if(doingRemount){
            if(++remountTicks > 5) {
                doingRemount = false;
                remountTicks = 0;
                mc.getNetworkHandler().sendPacket(new PlayerInteractEntityC2SPacket(mount, Hand.MAIN_HAND, false));
                lastRemount = System.currentTimeMillis();
            }
        }
    });

    public EntitySpeed() {
        super(Category.Movement, "entity-speed", "Makes you go faster when riding entities.");
    }
}
