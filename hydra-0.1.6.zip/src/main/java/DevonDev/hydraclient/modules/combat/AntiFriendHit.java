package DevonDev.hydraclient.modules.combat;

//Created by squidoodly 16/07/2020 (Yay! Empty class!!!)

import DevonDev.hydraclient.events.entity.player.AttackEntityEvent;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.PlayerEntity;

public class AntiFriendHit extends ToggleModule {
    @EventHandler
    private final Listener<AttackEntityEvent> onAttackEntity = new Listener<>(event -> {
        if (event.entity instanceof PlayerEntity && ModuleManager.INSTANCE.get(AntiFriendHit.class).isActive() && !FriendManager.INSTANCE.attack((PlayerEntity) event.entity))
            event.cancel();
    });

    public AntiFriendHit() {
        super(Category.Combat, "anti-friend-hit", "Cancels out attacks that would hit friends.");
    }
}
