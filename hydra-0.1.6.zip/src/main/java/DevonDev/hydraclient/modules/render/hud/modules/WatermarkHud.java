package DevonDev.hydraclient.modules.render.hud.modules;

import DevonDev.hydraclient.Config;
import DevonDev.hydraclient.modules.render.hud.HUD;

public class WatermarkHud extends DoubleTextHudModule {
    public WatermarkHud(HUD hud) {
        super(hud, "watermark", "Displays a hydra Client watermark.", "hydra Client ");
    }

    @Override
    protected String getRight() {
        return Config.INSTANCE.version.getOriginalString();
    }
}
