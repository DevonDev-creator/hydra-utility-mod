package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.events.render.RenderEvent;
import DevonDev.hydraclient.friends.Friend;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.rendering.Renderer;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Color;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class Tracers extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAppearance = settings.createGroup("Appearance");
    private final SettingGroup sgColors = settings.createGroup("Colors");
    private final Setting<List<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entites")
            .description("Select specific entities.")
            .defaultValue(new ArrayList<>(0))
            .build()
    );
    private final Setting<Boolean> storage = sgGeneral.add(new BoolSetting.Builder()
            .name("storage")
            .description("Displays storage blocks.")
            .defaultValue(false)
            .build()
    );

    // General
    private final Setting<Target> target = sgAppearance.add(new EnumSetting.Builder<Target>()
            .name("target")
            .description("Which body part to target.")
            .defaultValue(Target.Body)
            .build()
    );
    private final Setting<Mode> mode = sgAppearance.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .description("The rendering mode.")
            .defaultValue(Mode.Simple)
            .build()
    );

    // Appearance
    private final Setting<Color> playersColor = sgColors.add(new ColorSetting.Builder()
            .name("players-colors")
            .description("The player's color.")
            .defaultValue(new Color(205, 205, 205, 127))
            .build()
    );
    private final Setting<Color> animalsColor = sgColors.add(new ColorSetting.Builder()
            .name("animals-color")
            .description("The animal's color.")
            .defaultValue(new Color(145, 255, 145, 127))
            .build()
    );

    // Colors
    private final Setting<Color> waterAnimalsColor = sgColors.add(new ColorSetting.Builder()
            .name("water-animals-color")
            .description("The water animal's color.")
            .defaultValue(new Color(145, 145, 255, 127))
            .build()
    );
    private final Setting<Color> monstersColor = sgColors.add(new ColorSetting.Builder()
            .name("monsters-color")
            .description("The monster's color.")
            .defaultValue(new Color(255, 145, 145, 127))
            .build()
    );
    private final Setting<Color> ambientColor = sgColors.add(new ColorSetting.Builder()
            .name("ambient-color")
            .description("The ambient color.")
            .defaultValue(new Color(75, 75, 75, 127))
            .build()
    );
    private final Setting<Color> miscColor = sgColors.add(new ColorSetting.Builder()
            .name("misc-color")
            .description("The misc color.")
            .defaultValue(new Color(145, 145, 145, 127))
            .build()
    );
    private final Setting<Color> storageColor = sgColors.add(new ColorSetting.Builder()
            .name("storage-color")
            .description("The storage color.")
            .defaultValue(new Color(255, 160, 0, 127))
            .build()
    );
    private Vec3d vec1;
    private int count;
    @EventHandler
    private final Listener<RenderEvent> onRender = new Listener<>(event -> {
        count = 0;

        vec1 = new Vec3d(0, 0, 1)
                .rotateX(-(float) Math.toRadians(mc.gameRenderer.getCamera().getPitch()))
                .rotateY(-(float) Math.toRadians(mc.gameRenderer.getCamera().getYaw()))
                .add(mc.gameRenderer.getCamera().getPos());

        for (Entity entity : mc.world.getEntities()) {
            if ((!ModuleManager.INSTANCE.isActive(Freecam.class) && entity == mc.player) || !entities.get().contains(entity.getType()))
                continue;

            if (entity instanceof PlayerEntity) {
                Color color = playersColor.get();
                Friend friend = FriendManager.INSTANCE.get(((PlayerEntity) entity).getGameProfile().getName());
                if (friend != null) color = friend.color;

                if (friend == null || friend.showInTracers) render(entity, color, event);
            } else {
                switch (entity.getType().getSpawnGroup()) {
                    case CREATURE:
                        render(entity, animalsColor.get(), event);
                        break;
                    case WATER_CREATURE:
                        render(entity, waterAnimalsColor.get(), event);
                        break;
                    case MONSTER:
                        render(entity, monstersColor.get(), event);
                        break;
                    case AMBIENT:
                        render(entity, ambientColor.get(), event);
                        break;
                    case MISC:
                        render(entity, miscColor.get(), event);
                        break;
                }
            }
        }

        if (storage.get()) {
            for (BlockEntity blockEntity : mc.world.blockEntities) {
                if (blockEntity.isRemoved()) continue;

                if (blockEntity instanceof ChestBlockEntity || blockEntity instanceof BarrelBlockEntity || blockEntity instanceof ShulkerBoxBlockEntity) {
                    render(blockEntity, event);
                }
            }
        }
    });
    public Tracers() {
        super(Category.Render, "tracers", "Displays tracer lines to specified entities.");
    }

    private void render(Entity entity, Color color, RenderEvent event) {
        double x = entity.prevX + (entity.getX() - entity.prevX) * event.tickDelta;
        double y = entity.prevY + (entity.getY() - entity.prevY) * event.tickDelta;
        double z = entity.prevZ + (entity.getZ() - entity.prevZ) * event.tickDelta;

        double height = entity.getBoundingBox().maxY - entity.getBoundingBox().minY;

        if (target.get() == Target.Head) y += height;
        else if (target.get() == Target.Body) y += height / 2;

        Renderer.LINES.line(vec1.x - (mc.gameRenderer.getCamera().getPos().x - event.offsetX), vec1.y - (mc.gameRenderer.getCamera().getPos().y - event.offsetY), vec1.z - (mc.gameRenderer.getCamera().getPos().z - event.offsetZ), x, y, z, color);
        if (mode.get() == Mode.Stem) Renderer.LINES.line(x, entity.getY(), z, x, entity.getY() + height, z, color);

        count++;
    }

    private void render(BlockEntity blockEntity, RenderEvent event) {
        BlockPos pos = blockEntity.getPos();
        Renderer.LINES.line(vec1.x - (mc.gameRenderer.getCamera().getPos().x - event.offsetX), vec1.y - (mc.gameRenderer.getCamera().getPos().y - event.offsetY), vec1.z - (mc.gameRenderer.getCamera().getPos().z - event.offsetZ), pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5f, storageColor.get());

        count++;
    }

    @Override
    public String getInfoString() {
        return Integer.toString(count);
    }

    public enum Target {
        Head,
        Body,
        Feet
    }

    public enum Mode {
        Simple,
        Stem
    }
}
