package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;

public class Reach extends ToggleModule {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> reach = sg.add(new DoubleSetting.Builder()
            .name("reach")
            .description("Your reach.")
            .defaultValue(5)
            .min(0)
            .sliderMax(6)
            .build()
    );

    public Reach() {
        super(Category.Player, "reach", "Gives you super long arms.");
    }

    public float getReach() {
        return reach.get().floatValue();
    }
}
