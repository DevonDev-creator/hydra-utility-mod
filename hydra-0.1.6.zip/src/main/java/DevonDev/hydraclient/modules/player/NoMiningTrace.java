package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import net.minecraft.item.PickaxeItem;

public class NoMiningTrace extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> onlyWhenHoldingPickaxe = sgGeneral.add(new BoolSetting.Builder()
            .name("only-when-holding-pickaxe")
            .description("Only works when holding a pickaxe.")
            .defaultValue(true)
            .build()
    );

    public NoMiningTrace() {
        super(Category.Player, "no-mining-trace", "Allows you to mine blocks through entities.");
    }

    public boolean canWork() {
        if (!isActive()) return false;

        if (onlyWhenHoldingPickaxe.get()) {
            return mc.player.getMainHandStack().getItem() instanceof PickaxeItem || mc.player.getOffHandStack().getItem() instanceof PickaxeItem;
        }

        return true;
    }
}
