package DevonDev.hydraclient.modules.render.hud.modules;

import DevonDev.hydraclient.modules.render.hud.HUD;
import net.minecraft.client.MinecraftClient;

public class WelcomeHud extends DoubleTextHudModule {
    public WelcomeHud(HUD hud) {
        super(hud, "welcome", "Displays a welcome message.", "Welcome to Hydra Client, ");

        rightColor = hud.welcomeColor();
    }

    @Override
    protected String getRight() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return "UnknownPlayer!";

        return mc.player.getGameProfile().getName() + "!";
    }
}
