package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.events.render.RenderEvent;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.rendering.Renderer;
import DevonDev.hydraclient.rendering.ShapeMode;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Color;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

public class ESP extends ToggleModule {
    private static final Color WHITE = new Color(255, 255, 255);

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgColors = settings.createGroup("Colors");

    // General

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Both)
            .build()
    );

    private final Setting<Boolean> outline = sgGeneral.add(new BoolSetting.Builder()
            .name("outline")
            .description("Renders an outline around the entities.")
            .defaultValue(true)
            .build()
    );

    private final Setting<List<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entites")
            .description("Select specific entities.")
            .defaultValue(new ArrayList<>(0))
            .build()
    );

    // Colors

    private final Setting<Color> playersColor = sgColors.add(new ColorSetting.Builder()
            .name("players-color")
            .description("The other player's color.")
            .defaultValue(new Color(255, 255, 255))
            .build()
    );

    private final Setting<Color> animalsColor = sgColors.add(new ColorSetting.Builder()
            .name("animals-color")
            .description("The animal's color.")
            .defaultValue(new Color(25, 255, 25, 255))
            .build()
    );

    private final Setting<Color> waterAnimalsColor = sgColors.add(new ColorSetting.Builder()
            .name("water-animals-color")
            .description("The water animal's color.")
            .defaultValue(new Color(25, 25, 255, 255))
            .build()
    );

    private final Setting<Color> monstersColor = sgColors.add(new ColorSetting.Builder()
            .name("monsters-color")
            .description("The monster's color.")
            .defaultValue(new Color(255, 25, 25, 255))
            .build()
    );

    private final Setting<Color> ambientColor = sgColors.add(new ColorSetting.Builder()
            .name("ambient-color")
            .description("The ambient's color.")
            .defaultValue(new Color(25, 25, 25, 255))
            .build()
    );

    private final Setting<Color> miscColor = sgColors.add(new ColorSetting.Builder()
            .name("misc-color")
            .description("The misc color.")
            .defaultValue(new Color(175, 175, 175, 255))
            .build()
    );

    private final Setting<Double> fadeDistance = sgGeneral.add(new DoubleSetting.Builder()
            .name("fade-distance")
            .description("The distance where the color fades.")
            .defaultValue(6)
            .min(0)
            .sliderMax(12)
            .build()
    );

    private final Color sideColor = new Color();
    private final Color outlineColor = new Color();
    private int count;
    @EventHandler
    private final Listener<RenderEvent> onRender = new Listener<>(event -> {
        count = 0;

        for (Entity entity : mc.world.getEntities()) {
            if ((!ModuleManager.INSTANCE.isActive(Freecam.class) && entity == mc.player) || !entities.get().contains(entity.getType()))
                continue;
            count++;

            if (outline.get()) continue;
            render(event, entity, getColor(entity));
        }
    });

    public ESP() {
        super(Category.Render, "esp", "Renders entities through walls.");
    }

    private void setSideColor(Color lineColor) {
        sideColor.set(lineColor);
        sideColor.a = 25;
    }

    private void render(RenderEvent event, Entity entity, Color lineColor) {
        setSideColor(lineColor);

        double dist = mc.cameraEntity.squaredDistanceTo(entity.getX() + entity.getWidth() / 2, entity.getY() + entity.getHeight() / 2, entity.getZ() + entity.getWidth() / 2);
        double a = 1;
        if (dist <= fadeDistance.get() * fadeDistance.get()) a = dist / (fadeDistance.get() * fadeDistance.get());

        int prevLineA = lineColor.a;
        int prevSideA = sideColor.a;

        lineColor.a *= a;
        sideColor.a *= a;

        if (a >= 0.075) {
            double x = (entity.getX() - entity.prevX) * event.tickDelta;
            double y = (entity.getY() - entity.prevY) * event.tickDelta;
            double z = (entity.getZ() - entity.prevZ) * event.tickDelta;

            Box box = entity.getBoundingBox();
            Renderer.boxWithLines(Renderer.NORMAL, Renderer.LINES, x + box.minX, y + box.minY, z + box.minZ, x + box.maxX, y + box.maxY, z + box.maxZ, sideColor, lineColor, shapeMode.get(), 0);
        }

        lineColor.a = prevLineA;
        sideColor.a = prevSideA;
    }

    @Override
    public String getInfoString() {
        return Integer.toString(count);
    }

    public Color getColor(Entity entity) {
        if (entity instanceof PlayerEntity)
            return FriendManager.INSTANCE.getColor((PlayerEntity) entity, playersColor.get());

        switch (entity.getType().getSpawnGroup()) {
            case CREATURE:
                return animalsColor.get();
            case WATER_CREATURE:
                return waterAnimalsColor.get();
            case MONSTER:
                return monstersColor.get();
            case AMBIENT:
                return ambientColor.get();
            case MISC:
                return miscColor.get();
        }

        return WHITE;
    }

    public Color getOutlineColor(Entity entity) {
        if (!entities.get().contains(entity.getType())) return null;
        Color color = getColor(entity);

        double dist = mc.cameraEntity.squaredDistanceTo(entity.getX() + entity.getWidth() / 2, entity.getY() + entity.getHeight() / 2, entity.getZ() + entity.getWidth() / 2);
        double a = 1;
        if (dist <= fadeDistance.get() * fadeDistance.get()) a = dist / (fadeDistance.get() * fadeDistance.get());

        if (a >= 0.075) {
            outlineColor.set(color);
            outlineColor.a *= a;
            return outlineColor;
        }

        return null;
    }

    public boolean isOutline() {
        return outline.get();
    }
}
