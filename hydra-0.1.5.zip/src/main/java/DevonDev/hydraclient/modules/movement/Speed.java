package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.entity.player.PlayerMoveEvent;
import DevonDev.hydraclient.mixininterface.IVec3d;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.PlayerUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Vec3d;

public class Speed extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Speed.Mode> mode = sgGeneral.add(new EnumSetting.Builder<Speed.Mode>()
            .name("mode")
            .description("The mode used for bypasses.")
            .defaultValue(Mode.None)
            .build()
    );
    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
            .name("speed")
            .description("How fast you want to go in blocks per second.")
            .defaultValue(5.6)
            .min(0)
            .sliderMax(50)
            .build()
    );
    private final Setting<Boolean> onlyOnGround = sgGeneral.add(new BoolSetting.Builder()
            .name("only-on-ground")
            .description("Use speed only when standing on a block.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> inWater = sgGeneral.add(new BoolSetting.Builder()
            .name("in-water")
            .description("Use speed when in water.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> whenSneaking = sgGeneral.add(new BoolSetting.Builder()
            .name("when-sneaking")
            .description("Use speed when sneaking.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> applySpeedPotions = sgGeneral.add(new BoolSetting.Builder()
            .name("apply-speed-potions")
            .description("Apply the speed effect via potions.")
            .defaultValue(true)
            .build()
    );
    private boolean jumping;
    @EventHandler
    private final Listener<PlayerMoveEvent> onPlayerMove = new Listener<>(event -> {
        if (event.type != MovementType.SELF || mc.player.isFallFlying() || mc.player.isClimbing() || mc.player.getVehicle() != null)
            return;
        if (!whenSneaking.get() && mc.player.isSneaking()) return;
        if (onlyOnGround.get() && !mc.player.isOnGround()) return;
        if (!inWater.get() && mc.player.isTouchingWater()) return;

        Vec3d vel = PlayerUtils.getHorizontalVelocity(speed.get());
        double velX = vel.getX();
        double velZ = vel.getZ();
        if (mode.get() != Mode.None) {
            if (mc.options.keySneak.isPressed())
                return;
            double speeds = speed.get() / 30;

            if (mode.get() == Mode.Matrix) {
                if (mc.options.keyJump.isPressed() || mc.player.fallDistance > 0.25)
                    return;

                if (jumping && mc.player.getY() >= mc.player.prevY + 0.399994D) {
                    mc.player.setVelocity(mc.player.getVelocity().x, -0.9, mc.player.getVelocity().z);
                    mc.player.setPos(mc.player.getX(), mc.player.prevY, mc.player.getZ());
                    jumping = false;
                }

                if (mc.player.forwardSpeed != 0.0F && !mc.player.horizontalCollision) {
                    if (mc.player.verticalCollision) {
                        mc.player.setVelocity(mc.player.getVelocity().x * (0.85 + speeds), mc.player.getVelocity().y, mc.player.getVelocity().z * (0.85 + speeds));
                        jumping = true;
                        mc.player.jump();
                        // 1.0379
                    }

                    if (jumping && mc.player.getY() >= mc.player.prevY + 0.399994D) {
                        mc.player.setVelocity(mc.player.getVelocity().x, -100, mc.player.getVelocity().z);
                        jumping = false;
                    }

                }
            } else if (mode.get() == Mode.Spartan) {
                if (mc.player.horizontalCollision || mc.options.keyJump.isPressed() || mc.player.forwardSpeed == 0)
                    return;
                if (mc.player.isOnGround())
                    mc.player.jump();
                else if (mc.player.getVelocity().y > 0) {
                    mc.player.setVelocity(mc.player.getVelocity().x * (0.9 + speeds), -1, mc.player.getVelocity().z * (0.9 + speeds));
                    mc.player.input.movementSideways += 1.5F;
                }
            } else if (mode.get() == Mode.AAC_4) {
                if (mc.player.forwardSpeed > 0 && mc.player.isOnGround()) {
                    mc.player.jump();
                    mc.player.setVelocity(mc.player.getVelocity().x * (0.65 + speeds), 0.255556, mc.player.getVelocity().z * (0.65 + speeds));
                    mc.player.sidewaysSpeed += 3.0F;
                    mc.player.jump();
                    mc.player.setSprinting(true);
                }
            }
        } else {
            if (applySpeedPotions.get() && mc.player.hasStatusEffect(StatusEffects.SPEED)) {
                double value = (mc.player.getStatusEffect(StatusEffects.SPEED).getAmplifier() + 1) * 0.205;
                velX += velX * value;
                velZ += velZ * value;
            }

            Anchor anchor = ModuleManager.INSTANCE.get(Anchor.class);
            if (anchor.isActive() && anchor.controlMovement) {
                velX = anchor.deltaX;
                velZ = anchor.deltaZ;
            }

            ((IVec3d) event.movement).set(velX, event.movement.y, velZ);
        }
    });

    public Speed() {
        super(Category.Movement, "speed", "Speeeeeed.");
    }

    public enum Mode {
        None,
        Spartan,
        Matrix,
        AAC_V5,
        AAC_4
    }
}
