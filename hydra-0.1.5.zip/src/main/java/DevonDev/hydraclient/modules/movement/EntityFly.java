package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.entity.BoatMoveEvent;
import DevonDev.hydraclient.events.entity.LivingEntityMoveEvent;
import DevonDev.hydraclient.events.packets.ReceivePacketEvent;
import DevonDev.hydraclient.mixininterface.IVec3d;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.PlayerUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.packet.s2c.play.VehicleMoveS2CPacket;
import net.minecraft.util.math.Vec3d;

public class EntityFly extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
            .name("speed")
            .description("Horizontal speed in blocks per second.")
            .defaultValue(10)
            .min(0)
            .sliderMax(50)
            .build()
    );

    private final Setting<Double> verticalSpeed = sgGeneral.add(new DoubleSetting.Builder()
            .name("vertical-speed")
            .description("Vertical speed in blocks per second.")
            .defaultValue(6)
            .min(0)
            .sliderMax(20)
            .build()
    );

    private final Setting<Double> fallSpeed = sgGeneral.add(new DoubleSetting.Builder()
            .name("fall-speed")
            .description("How fast you fall in blocks per second.")
            .defaultValue(0.1)
            .min(0)
            .build()
    );

    private final Setting<Boolean> cancelServerPackets = sgGeneral.add(new BoolSetting.Builder()
            .name("cancel-server-packets")
            .description("Cancels incoming boat move packets.")
            .defaultValue(false)
            .build()
    );
    @EventHandler
    private final Listener<LivingEntityMoveEvent> onLivingEntityMove = new Listener<>(event -> {
        if (event.entity.getPrimaryPassenger() != mc.player) return;

        event.entity.yaw = mc.player.yaw;

        // Horizontal movement
        Vec3d vel = PlayerUtils.getHorizontalVelocity(speed.get());
        double velX = vel.getX();
        double velY = 0;
        double velZ = vel.getZ();

        // Vertical movement
        if (mc.options.keyJump.isPressed()) velY += verticalSpeed.get() / 20;
        if (mc.options.keySprint.isPressed()) velY -= verticalSpeed.get() / 20;
        else velY -= fallSpeed.get() / 20;

        // Apply velocity
        ((IVec3d) event.entity.getVelocity()).set(velX, velY, velZ);
    });
    @EventHandler
    private final Listener<ReceivePacketEvent> onReceivePacket = new Listener<>(event -> {
        if (event.packet instanceof VehicleMoveS2CPacket && cancelServerPackets.get()) {
            event.cancel();
        }
    });

    public EntityFly() {
        super(Category.Movement, "entity-fly", "Transforms your entity into a plane.");
    }
}
