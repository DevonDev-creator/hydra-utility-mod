package DevonDev.hydraclient.mixin;

import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.events.EventStore;
import DevonDev.hydraclient.events.entity.player.ClipAtLedgeEvent;
import DevonDev.hydraclient.mixininterface.IPlayerEntity;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.movement.Anchor;
import DevonDev.hydraclient.modules.player.SpeedMine;
import net.minecraft.block.BlockState;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public class PlayerEntityMixin implements IPlayerEntity {
    @Shadow
    @Final
    @Mutable
    public PlayerInventory inventory;

    @Inject(method = "clipAtLedge", at = @At("HEAD"), cancellable = true)
    protected void clipAtLedge(CallbackInfoReturnable<Boolean> info) {
        ClipAtLedgeEvent event = HydraClient.postEvent(EventStore.clipAtLedgeEvent());
        if (event.isSet()) info.setReturnValue(event.isClip());
    }

    @Inject(method = "dropItem(Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/ItemEntity;", at = @At("HEAD"))
    private void onDropItem(ItemStack stack, boolean bl, boolean bl2, CallbackInfoReturnable<ItemEntity> info) {
        HydraClient.EVENT_BUS.post(EventStore.dropItemEvent(stack));
    }

    @Override
    public void setInventory(PlayerInventory inventory) {
        this.inventory = inventory;
    }

    @Inject(method = "getBlockBreakingSpeed", at = @At(value = "RETURN"), cancellable = true)
    public void onGetBlockBreakingSpeed(BlockState block, CallbackInfoReturnable<Float> cir) {
        SpeedMine module = ModuleManager.INSTANCE.get(SpeedMine.class);
        if (!module.isActive() || module.mode.get() != SpeedMine.Mode.Normal)
            return;
        cir.setReturnValue((float) (cir.getReturnValue() * module.modifier.get()));
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    public void dontJump(CallbackInfo info) {
        Anchor module = ModuleManager.INSTANCE.get(Anchor.class);
        if (module.isActive() && module.cancelJump) info.cancel();
    }
}
