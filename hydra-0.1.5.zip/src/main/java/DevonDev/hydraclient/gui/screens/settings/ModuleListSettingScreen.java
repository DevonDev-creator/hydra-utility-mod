package DevonDev.hydraclient.gui.screens.settings;

import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.gui.widgets.WWidget;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.Setting;

import java.util.List;

public class ModuleListSettingScreen extends LeftRightListSettingScreen<ToggleModule> {
    public ModuleListSettingScreen(Setting<List<ToggleModule>> setting) {
        super("Select Modules", setting, ModuleManager.REGISTRY);
    }

    @Override
    protected WWidget getValueWidget(ToggleModule value) {
        return new WLabel(value.title);
    }

    @Override
    protected String getValueName(ToggleModule value) {
        return value.title;
    }
}
