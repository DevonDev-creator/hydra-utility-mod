package DevonDev.hydraclient.events.packets;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.network.Packet;

public class ReceivePacketEvent extends Cancellable {
    public Packet<?> packet;
}
