package DevonDev.hydraclient.events.entity.player;

import net.minecraft.item.ItemStack;

public class PickItemsEvent {
    public ItemStack itemStack;
    public int count;
}
