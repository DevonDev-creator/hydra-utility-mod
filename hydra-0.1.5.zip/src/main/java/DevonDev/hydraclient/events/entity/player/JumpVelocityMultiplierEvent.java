package DevonDev.hydraclient.events.entity.player;

public class JumpVelocityMultiplierEvent {
    public float multiplier = 1;
}
