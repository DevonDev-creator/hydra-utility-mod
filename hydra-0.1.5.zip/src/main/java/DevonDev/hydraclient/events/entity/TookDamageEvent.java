package DevonDev.hydraclient.events.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class TookDamageEvent {
    public LivingEntity entity;
    public DamageSource source;
}
