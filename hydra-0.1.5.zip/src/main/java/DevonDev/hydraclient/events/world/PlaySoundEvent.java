package DevonDev.hydraclient.events.world;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.client.sound.SoundInstance;

public class PlaySoundEvent extends Cancellable {
    public SoundInstance sound;
}
