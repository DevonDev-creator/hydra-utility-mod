package DevonDev.hydraclient.events.hydra;

import DevonDev.hydraclient.modules.ToggleModule;

public class ModuleVisibilityChangedEvent {
    public ToggleModule module;
}
