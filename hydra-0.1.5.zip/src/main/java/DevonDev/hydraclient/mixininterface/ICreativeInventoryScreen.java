

package DevonDev.hydraclient.mixininterface;

public interface ICreativeInventoryScreen {
    int getSelectedTab();
}
