

package DevonDev.hydraclient.mixininterface;

import net.minecraft.text.Text;

public interface IAbstractButtonWidget {
    void setText(Text text);
}
