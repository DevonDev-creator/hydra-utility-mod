

package DevonDev.hydraclient.mixininterface;

public interface IStatusEffectInstance {
    void setDuration(int duration);

    void setAmplifier(int amplifier);
}
