package DevonDev.hydraclient.gui.widgets;

public interface WRoot {
}
