package DevonDev.hydraclient.gui.screens.settings;

import DevonDev.hydraclient.gui.screens.WindowScreen;
import DevonDev.hydraclient.gui.widgets.WCheckbox;
import DevonDev.hydraclient.gui.widgets.WLabel;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.StorageBlockListSetting;
import net.minecraft.block.entity.BlockEntityType;

import java.util.List;

public class StorageBlockListSettingScreen extends WindowScreen {
    public StorageBlockListSettingScreen(Setting<List<BlockEntityType<?>>> setting) {
        super("Select storage blocks", true);

        for (int i = 0; i < StorageBlockListSetting.STORAGE_BLOCKS.length; i++) {
            BlockEntityType<?> type = StorageBlockListSetting.STORAGE_BLOCKS[i];
            String name = StorageBlockListSetting.STORAGE_BLOCK_NAMES[i];

            add(new WLabel(name));
            WCheckbox checkbox = add(new WCheckbox(setting.get().contains(type))).fillX().right().getWidget();
            checkbox.action = () -> {
                if (checkbox.checked && !setting.get().contains(type)) {
                    setting.get().add(type);
                    setting.changed();
                } else if (!checkbox.checked && setting.get().remove(type)) {
                    setting.changed();
                }
            };

            row();
        }
    }
}
