package DevonDev.hydraclient.gui.screens.topbar;

import DevonDev.hydraclient.gui.WidgetScreen;
import DevonDev.hydraclient.gui.widgets.WTopBar;

public abstract class TopBarScreen extends WidgetScreen {
    public final TopBarType type;

    public TopBarScreen(TopBarType type) {
        super(type.toString());
        this.type = type;
    }

    protected void addTopBar() {
        super.add(new WTopBar()).centerX();
    }
}
