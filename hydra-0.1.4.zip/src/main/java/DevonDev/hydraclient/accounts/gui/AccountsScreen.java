package DevonDev.hydraclient.accounts.gui;

import DevonDev.hydraclient.accounts.Account;
import DevonDev.hydraclient.accounts.AccountManager;
import DevonDev.hydraclient.events.hydra.AccountListChangedEvent;
import DevonDev.hydraclient.gui.WidgetScreen;
import DevonDev.hydraclient.gui.screens.WindowScreen;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WTable;
import DevonDev.hydraclient.utils.HydraExecutor;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.MinecraftClient;

public class AccountsScreen extends WindowScreen {
    @EventHandler
    private final Listener<AccountListChangedEvent> onAccountListChanged = new Listener<>(event -> {
        clear();
        initWidgets();
    });

    public AccountsScreen() {
        super("Accounts", true);

        initWidgets();
    }

    static void addAccount(WButton add, WidgetScreen screen, Account<?> account) {
        add.setText("...");
        screen.locked = true;

        HydraExecutor.execute(() -> {
            if (account.fetchInfo() && account.fetchHead()) {
                AccountManager.INSTANCE.add(account);
                screen.locked = false;
                screen.onClose();
            }

            add.setText("Add");
            screen.locked = false;
        });
    }

    void initWidgets() {
        // Accounts
        if (AccountManager.INSTANCE.size() > 0) {
            WTable t = add(new WTable()).fillX().expandX().getWidget();
            row();

            for (Account<?> account : AccountManager.INSTANCE) {
                t.add(new WAccount(this, account)).fillX().expandX();
                t.row();
            }
        }

        // Add account
        WTable t = add(new WTable()).fillX().expandX().getWidget();
        addButton(t, "Cracked", () -> MinecraftClient.getInstance().openScreen(new AddCrackedAccountScreen()));
        addButton(t, "Premium", () -> MinecraftClient.getInstance().openScreen(new AddPremiumAccountScreen()));
        addButton(t, "The Altening", () -> MinecraftClient.getInstance().openScreen(new AddTheAlteningAccountScreen()));
    }

    private void addButton(WTable t, String text, Runnable action) {
        WButton button = t.add(new WButton(text)).fillX().expandX().getWidget();
        button.action = action;
    }
}
