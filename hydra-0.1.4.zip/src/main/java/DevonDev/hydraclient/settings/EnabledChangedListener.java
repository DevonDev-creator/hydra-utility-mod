

package DevonDev.hydraclient.settings;

public interface EnabledChangedListener {
    void onEnabledChanged(SettingGroup settingGroup);
}
