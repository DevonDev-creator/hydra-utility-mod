package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.commands.arguments.ModuleArgumentType;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.Chat;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Settings extends Command {
    public Settings() {
        super("settings", "Displays all settings of specified module.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("module", ModuleArgumentType.module()).executes(context -> {
            Module module = context.getArgument("module", Module.class);

            Chat.info("(highlight)%s(default):", module.title);
            for (SettingGroup sg : module.settings) {
                for (Setting<?> setting : sg) {
                    Chat.info("  Usage of (highlight)%s (default)(%s) is (highlight)%s(default).", setting.name, setting.get().toString(), setting.getUsage());
                }
            }

            return SINGLE_SUCCESS;
        }));
    }
}
