package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.Config;
import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.Module;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.utils.Chat;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import java.util.List;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Modules extends Command {
    public Modules() {
        super("modules", "Lists all modules.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            Chat.info("All (highlight)%d (default)modules:", ModuleManager.INSTANCE.getAll().size());

            for (Category category : ModuleManager.CATEGORIES) {
                List<Module> group = ModuleManager.INSTANCE.getGroup(category);
                Chat.info("- (highlight)%s (default)(%d):", category.toString(), group.size());

                for (Module module : group) {
                    Chat.info("  - (highlight)%s%s (default)- %s", Config.INSTANCE.getPrefix(), module.name, module.description);
                }
            }

            return SINGLE_SUCCESS;
        });
    }
}
