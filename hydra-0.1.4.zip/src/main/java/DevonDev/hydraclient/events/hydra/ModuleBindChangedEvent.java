package DevonDev.hydraclient.events.hydra;

import DevonDev.hydraclient.modules.Module;

public class ModuleBindChangedEvent {
    public Module module;
}
