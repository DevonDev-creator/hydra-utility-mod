package DevonDev.hydraclient.events.game;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.client.gui.screen.Screen;

public class OpenScreenEvent extends Cancellable {
    public Screen screen;
}
