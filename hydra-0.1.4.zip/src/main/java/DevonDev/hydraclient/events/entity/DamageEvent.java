package DevonDev.hydraclient.events.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class DamageEvent {
    public LivingEntity entity;
    public DamageSource source;
}
