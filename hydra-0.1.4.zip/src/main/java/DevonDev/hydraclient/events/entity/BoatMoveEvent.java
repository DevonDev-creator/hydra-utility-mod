package DevonDev.hydraclient.events.entity;

import net.minecraft.entity.vehicle.BoatEntity;

public class BoatMoveEvent {
    public BoatEntity boat;
}
