package DevonDev.hydraclient.mixin;

import DevonDev.hydraclient.HydraClient;
import DevonDev.hydraclient.events.EventStore;
import DevonDev.hydraclient.events.hydra.CharTypedEvent;
import DevonDev.hydraclient.events.hydra.KeyEvent;
import DevonDev.hydraclient.gui.GuiKeyEvents;
import DevonDev.hydraclient.gui.WidgetScreen;
import DevonDev.hydraclient.utils.Input;
import DevonDev.hydraclient.utils.KeyAction;
import DevonDev.hydraclient.utils.Utils;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public abstract class KeyboardMixin {
    @Shadow
    @Final
    private MinecraftClient client;

    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    public void onKey(long window, int key, int scancode, int i, int j, CallbackInfo info) {
        if (key != GLFW.GLFW_KEY_UNKNOWN) {
            if (client.currentScreen instanceof WidgetScreen && i == GLFW.GLFW_REPEAT) {
                ((WidgetScreen) client.currentScreen).keyRepeated(key, j);
            }

            if (GuiKeyEvents.postKeyEvents()) {
                Input.setKeyState(key, i != GLFW.GLFW_RELEASE);

                KeyEvent event = EventStore.keyEvent(key, KeyAction.get(i));
                HydraClient.EVENT_BUS.post(event);

                if (event.isCancelled()) info.cancel();
            }
        }
    }

    @Inject(method = "onChar", at = @At("HEAD"), cancellable = true)
    private void onChar(long window, int i, int j, CallbackInfo info) {
        if (Utils.canUpdate() && !client.isPaused() && (client.currentScreen == null || client.currentScreen instanceof WidgetScreen)) {
            CharTypedEvent event = EventStore.charTypedEvent((char) i);
            HydraClient.EVENT_BUS.post(event);

            if (event.isCancelled()) info.cancel();
        }
    }
}
