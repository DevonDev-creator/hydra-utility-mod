package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.entity.player.ClipAtLedgeEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class SafeWalk extends ToggleModule {
    @EventHandler
    private final Listener<ClipAtLedgeEvent> onClipAtLedge = new Listener<>(event -> {
        event.setClip(true);
    });

    public SafeWalk() {
        super(Category.Movement, "safe-walk", "Prevents you from walking off blocks. Useful over a void.");
    }
}
