package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.EnumSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class AutoJump extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<JumpIf> jumpIf = sgGeneral.add(new EnumSetting.Builder<JumpIf>()
            .name("jump-if")
            .description("Jump if.")
            .defaultValue(JumpIf.Always)
            .build()
    );
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (!mc.player.isOnGround() || mc.player.isSneaking()) return;

        if (jump()) mc.player.jump();
    });

    public AutoJump() {
        super(Category.Movement, "auto-jump", "Automatically jumps.");
    }

    private boolean jump() {
        switch (jumpIf.get()) {
            case Sprinting:
                return mc.player.isSprinting() && (mc.player.forwardSpeed != 0 || mc.player.sidewaysSpeed != 0);
            case Walking:
                return mc.player.forwardSpeed != 0 || mc.player.sidewaysSpeed != 0;
            case Always:
                return true;
            default:
                return false;
        }
    }

    public enum JumpIf {
        Sprinting,
        Walking,
        Always
    }
}
