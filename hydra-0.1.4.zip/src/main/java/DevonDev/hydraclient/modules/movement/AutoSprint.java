package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class AutoSprint extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> permanent = sgGeneral.add(new BoolSetting.Builder()
            .name("permanent")
            .description("Makes you still sprint even if you do not move.")
            .defaultValue(true)
            .build()
    );
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (mc.player.forwardSpeed > 0 && !permanent.get()) {
            mc.player.setSprinting(true);
        } else if (permanent.get()) {
            mc.player.setSprinting(true);
        }
    });

    public AutoSprint() {
        super(Category.Movement, "auto-sprint", "Automatically sprints.");
    }

    @Override
    public void onDeactivate() {
        mc.player.setSprinting(false);
    }
}
