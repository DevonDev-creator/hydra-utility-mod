package DevonDev.hydraclient.modules.misc;

import DevonDev.hydraclient.events.hydra.MiddleMouseButtonEvent;
import DevonDev.hydraclient.friends.Friend;
import DevonDev.hydraclient.friends.FriendManager;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.PlayerEntity;

public class MiddleClickFriend extends ToggleModule {
    @EventHandler
    private final Listener<MiddleMouseButtonEvent> onMiddleMouseButton = new Listener<>(event -> {
        if (mc.currentScreen != null) return;
        if (mc.targetedEntity instanceof PlayerEntity)
            FriendManager.INSTANCE.addOrRemove(new Friend((PlayerEntity) mc.targetedEntity));
    });

    public MiddleClickFriend() {
        super(Category.Misc, "middle-click-friend", "Adds or removes a player as a friend via middle click.");
    }
}
