package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.events.packets.SendPacketEvent;
import DevonDev.hydraclient.mixininterface.IBlockHitResult;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.math.Direction;

public class BuildHeight extends ToggleModule {
    @EventHandler
    private final Listener<SendPacketEvent> onSendPacket = new Listener<>(event -> {
        if (!(event.packet instanceof PlayerInteractBlockC2SPacket)) return;

        PlayerInteractBlockC2SPacket p = (PlayerInteractBlockC2SPacket) event.packet;
        if (p.getBlockHitResult().getPos().y >= 255 && p.getBlockHitResult().getSide() == Direction.UP) {
            ((IBlockHitResult) p.getBlockHitResult()).setSide(Direction.DOWN);
        }
    });

    public BuildHeight() {
        super(Category.Player, "build-height", "Lets your interact with objects at the build limit.");
    }
}
