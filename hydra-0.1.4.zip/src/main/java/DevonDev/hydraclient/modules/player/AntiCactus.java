package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class AntiCactus extends ToggleModule {
    public AntiCactus() {
        super(Category.Player, "anti-cactus", "Prevents you from taking damage from cacti.");
    }
}
