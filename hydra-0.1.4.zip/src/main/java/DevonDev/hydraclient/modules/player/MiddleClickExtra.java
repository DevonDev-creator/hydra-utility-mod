package DevonDev.hydraclient.modules.player;

//Created by squidoodly 06/07/2020

import DevonDev.hydraclient.events.hydra.MiddleMouseButtonEvent;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.mixininterface.IKeyBinding;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.EnumSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.Chat;
import DevonDev.hydraclient.utils.InvUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class MiddleClickExtra extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .description("What to do when you middle click.")
            .defaultValue(Mode.Pearl)
            .build()
    );
    private final Setting<Boolean> notify = sgGeneral.add(new BoolSetting.Builder()
            .name("notify")
            .description("Notifies you when you do not have the specified item in your hotbar.")
            .defaultValue(true)
            .build()
    );
    private boolean wasUsing = false;
    private int preSlot;

    // Item specification errors.
    private int preCount;
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (!wasUsing) return;
        if (preCount > InvUtils.findItemWithCount(mode.get().item).count || (mc.player.getMainHandStack().getItem() != mode.get().item
                && (mode.get() == Mode.Bow && mc.player.getMainHandStack().getItem() != Items.BOW))) {
            ((IKeyBinding) mc.options.keyUse).setPressed(false);
            mc.player.inventory.selectedSlot = preSlot;
            wasUsing = false;
        } else {
            ((IKeyBinding) mc.options.keyUse).setPressed(true);
        }
    });
    private InvUtils.FindItemResult result;
    @EventHandler
    private final Listener<MiddleMouseButtonEvent> onMiddleMouse = new Listener<>(event -> {
        switch (mode.get()) {
            case Pearl: {
                result = InvUtils.findItemWithCount(Items.ENDER_PEARL);
                if (result.slot <= 8 && result.slot != -1) {
                    preSlot = mc.player.inventory.selectedSlot;
                    mc.player.inventory.selectedSlot = result.slot;
                    mc.interactionManager.interactItem(mc.player, mc.world, Hand.MAIN_HAND);
                    mc.player.inventory.selectedSlot = preSlot;
                } else if (notify.get()) {
                    Chat.error(this, "Unable to find specified item.");
                }
                break;
            }
            case Gap: {
                result = InvUtils.findItemWithCount(Items.GOLDEN_APPLE);
                if (result.slot <= 8 && result.slot != -1) {
                    preSlot = mc.player.inventory.selectedSlot;
                    mc.player.inventory.selectedSlot = result.slot;
                    preCount = result.count;
                    ((IKeyBinding) mc.options.keyUse).setPressed(true);
                    wasUsing = true;
                } else if (notify.get()) {
                    Chat.error(this, "Unable to find specified item.");
                }
                break;
            }
            case EGap: {
                result = InvUtils.findItemWithCount(Items.ENCHANTED_GOLDEN_APPLE);
                if (result.slot <= 8 && result.slot != -1) {
                    preSlot = mc.player.inventory.selectedSlot;
                    mc.player.inventory.selectedSlot = result.slot;
                    preCount = result.count;
                    ((IKeyBinding) mc.options.keyUse).setPressed(true);
                    wasUsing = true;
                } else if (notify.get()) {
                    Chat.error(this, "Unable to find selected item.");
                }
                break;
            }
            case Bow: {
                result = InvUtils.findItemWithCount(Items.BOW);
                if (result.slot <= 8 && result.slot != -1) {
                    preSlot = mc.player.inventory.selectedSlot;
                    mc.player.inventory.selectedSlot = result.slot;
                    result = InvUtils.findItemWithCount(Items.ARROW);
                    preCount = result.count;
                    wasUsing = true;
                } else if (notify.get()) {
                    Chat.error(this, "Unable to find specified item.");
                }
                break;
            }
            case Rod: {
                result = InvUtils.findItemWithCount(Items.FISHING_ROD);
                if (result.slot <= 8 && result.slot != -1) {
                    preSlot = mc.player.inventory.selectedSlot;
                    mc.player.inventory.selectedSlot = result.slot;
                    mc.interactionManager.interactItem(mc.player, mc.world, Hand.MAIN_HAND);
                } else if (notify.get()) {
                    Chat.error(this, "Unable to find specified item.");
                }
                break;
            }
        }
    });

    public MiddleClickExtra() {
        super(Category.Player, "middle-click-extra", "Lets you use items when you middle click. Works the same as Middle Click Friend.");
    }

    public enum Mode {
        Pearl(Items.ENDER_PEARL),
        Bow(Items.ARROW),
        Gap(Items.GOLDEN_APPLE),
        EGap(Items.ENCHANTED_GOLDEN_APPLE),
        Rod(Items.FISHING_ROD);

        private final Item item;

        Mode(Item item) {
            this.item = item;
        }
    }
}
