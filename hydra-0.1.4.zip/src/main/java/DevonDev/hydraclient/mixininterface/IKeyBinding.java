

package DevonDev.hydraclient.mixininterface;

public interface IKeyBinding {
    void setPressed(boolean pressed);
}
