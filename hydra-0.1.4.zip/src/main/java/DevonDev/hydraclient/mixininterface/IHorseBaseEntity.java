

package DevonDev.hydraclient.mixininterface;

public interface IHorseBaseEntity {
    void setSaddled(boolean saddled);
}
