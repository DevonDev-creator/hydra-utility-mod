

package DevonDev.hydraclient.mixininterface;

import net.minecraft.client.texture.Sprite;

public interface IBakedQuad {
    Sprite getSprite();
}
