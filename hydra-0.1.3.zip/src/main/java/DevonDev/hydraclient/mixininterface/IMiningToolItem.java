

package DevonDev.hydraclient.mixininterface;

import net.minecraft.block.Block;

public interface IMiningToolItem {
    boolean isEffectiveOn(Block block);
}
