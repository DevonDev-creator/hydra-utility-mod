

package DevonDev.hydraclient.mixininterface;

import net.minecraft.block.entity.SignBlockEntity;

public interface ISignEditScreen {
    SignBlockEntity getSign();
}
