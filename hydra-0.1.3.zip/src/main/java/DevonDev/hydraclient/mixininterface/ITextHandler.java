

package DevonDev.hydraclient.mixininterface;

import net.minecraft.client.font.TextHandler;

public interface ITextHandler {
    TextHandler.WidthRetriever getWidthRetriever();
}
