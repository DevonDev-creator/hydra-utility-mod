package DevonDev.hydraclient.events.entity.player;

import DevonDev.hydraclient.events.Cancellable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class StartBreakingBlockEvent extends Cancellable {
    public BlockPos blockPos;
    public Direction direction;
}
