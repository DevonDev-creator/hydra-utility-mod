package DevonDev.hydraclient.events.world;

import DevonDev.hydraclient.events.Cancellable;

public class ChunkOcclusionEvent extends Cancellable {
}
