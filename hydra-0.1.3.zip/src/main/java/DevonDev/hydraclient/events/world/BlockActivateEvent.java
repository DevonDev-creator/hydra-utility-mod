package DevonDev.hydraclient.events.world;

import net.minecraft.block.BlockState;

public class BlockActivateEvent {
    public BlockState blockState;
}
