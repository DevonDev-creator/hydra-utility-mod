package DevonDev.hydraclient.events.packets;

import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;

public class PlaySoundPacketEvent {
    public PlaySoundS2CPacket packet;
}
