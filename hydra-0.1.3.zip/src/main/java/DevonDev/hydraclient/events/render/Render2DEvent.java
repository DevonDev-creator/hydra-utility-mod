package DevonDev.hydraclient.events.render;

public class Render2DEvent {
    public int screenWidth, screenHeight;
    public float tickDelta;
}
