package DevonDev.hydraclient.gui.widgets;

import DevonDev.hydraclient.gui.GuiConfig;
import DevonDev.hydraclient.gui.renderer.GuiRenderer;
import DevonDev.hydraclient.utils.Color;

public class WTriangle extends WPressable {
    public Color color, colorHovered, colorPressed;

    public double rotation;

    public WTriangle() {
        color = GuiConfig.INSTANCE.background;
        colorHovered = GuiConfig.INSTANCE.backgroundHovered;
        colorPressed = GuiConfig.INSTANCE.backgroundPressed;
    }

    @Override
    protected void onCalculateSize(GuiRenderer renderer) {
        width = height = renderer.textHeight();
    }

    @Override
    protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
        Color color;
        if (pressed) color = colorPressed;
        else if (mouseOver) color = colorHovered;
        else color = this.color;

        renderer.triangle(x, y + width / 4, width, rotation, color);
    }
}
