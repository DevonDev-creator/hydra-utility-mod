package DevonDev.hydraclient.commands.commands;

import DevonDev.hydraclient.commands.Command;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;

import java.util.ArrayList;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class Panic extends Command {
    public Panic() {
        super("panic", "Disables all modules. DOES NOT remove keybinds.");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            new ArrayList<>(ModuleManager.INSTANCE.getActive()).forEach(ToggleModule::toggle);

            return SINGLE_SUCCESS;
        });
    }
}
