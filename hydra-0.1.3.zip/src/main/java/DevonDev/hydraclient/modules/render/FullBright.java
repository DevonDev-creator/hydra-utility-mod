package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class FullBright extends ToggleModule {

    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        mc.options.gamma = 16;
    });

    public FullBright() {
        super(Category.Render, "full-bright", "No more darkness.");
    }

    @Override
    public void onActivate() {
        mc.options.gamma = 16;
    }

    @Override
    public void onDeactivate() {
        mc.options.gamma = 1;
    }
}
