package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class CameraClip extends ToggleModule {
    public CameraClip() {
        super(Category.Render, "camera-clip", "Allows your third person camera to clip through blocks.");
    }
}
