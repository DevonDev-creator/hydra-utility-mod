package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.events.render.RenderEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.rendering.Renderer;
import DevonDev.hydraclient.rendering.ShapeMode;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Color;
import DevonDev.hydraclient.utils.Dir;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.*;
import net.minecraft.block.enums.ChestType;

import java.util.Arrays;
import java.util.List;

public class StorageESP extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<BlockEntityType<?>>> storageBlocks = sgGeneral.add(new StorageBlockListSetting.Builder()
            .name("storage-blocks")
            .description("Select the storage blocks to display.")
            .defaultValue(Arrays.asList(StorageBlockListSetting.STORAGE_BLOCKS))
            .build()
    );

    private final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Both)
            .build()
    );

    private final Setting<Color> chest = sgGeneral.add(new ColorSetting.Builder()
            .name("chest")
            .description("The color of chests.")
            .defaultValue(new Color(255, 160, 0, 255))
            .build()
    );

    private final Setting<Color> barrel = sgGeneral.add(new ColorSetting.Builder()
            .name("barrel")
            .description("The color of barrels.")
            .defaultValue(new Color(255, 160, 0, 255))
            .build()
    );

    private final Setting<Color> shulker = sgGeneral.add(new ColorSetting.Builder()
            .name("shulker")
            .description("The color of Shulker Boxes.")
            .defaultValue(new Color(255, 160, 0, 255))
            .build()
    );

    private final Setting<Color> enderChest = sgGeneral.add(new ColorSetting.Builder()
            .name("ender-chest")
            .description("The color of Ender Chests.")
            .defaultValue(new Color(120, 0, 255, 255))
            .build()
    );

    private final Setting<Color> other = sgGeneral.add(new ColorSetting.Builder()
            .name("other")
            .description("The color of furnaces, dispenders, droppers and hoppers.")
            .defaultValue(new Color(140, 140, 140, 255))
            .build()
    );

    private final Setting<Double> fadeDistance = sgGeneral.add(new DoubleSetting.Builder()
            .name("fade-distance")
            .description("The distance at which the color will fade.")
            .defaultValue(6)
            .min(0)
            .sliderMax(12)
            .build()
    );

    private final Color lineColor = new Color(0, 0, 0, 0);
    private final Color sideColor = new Color(0, 0, 0, 0);
    private boolean render;
    private int count;
    @EventHandler
    private final Listener<RenderEvent> onRender = new Listener<>(event -> {
        count = 0;

        for (BlockEntity blockEntity : mc.world.blockEntities) {
            if (blockEntity.isRemoved()) continue;

            getTileEntityColor(blockEntity);

            if (render) {
                double x1 = blockEntity.getPos().getX();
                double y1 = blockEntity.getPos().getY();
                double z1 = blockEntity.getPos().getZ();

                double x2 = blockEntity.getPos().getX() + 1;
                double y2 = blockEntity.getPos().getY() + 1;
                double z2 = blockEntity.getPos().getZ() + 1;

                int excludeDir = 0;
                if (blockEntity instanceof ChestBlockEntity) {
                    BlockState state = mc.world.getBlockState(blockEntity.getPos());
                    if ((state.getBlock() == Blocks.CHEST || state.getBlock() == Blocks.TRAPPED_CHEST) && state.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                        excludeDir = Dir.get(ChestBlock.getFacing(state));
                    }
                }

                if (blockEntity instanceof ChestBlockEntity || blockEntity instanceof EnderChestBlockEntity) {
                    double a = 1.0 / 16.0;

                    if (Dir.is(excludeDir, Dir.WEST)) x1 += a;
                    if (Dir.is(excludeDir, Dir.NORTH)) z1 += a;

                    if (Dir.is(excludeDir, Dir.EAST)) x2 -= a;
                    y2 -= a * 2;
                    if (Dir.is(excludeDir, Dir.SOUTH)) z2 -= a;
                }

                double dist = mc.player.squaredDistanceTo(blockEntity.getPos().getX() + 1, blockEntity.getPos().getY() + 1, blockEntity.getPos().getZ() + 1);
                double a = 1;
                if (dist <= fadeDistance.get() * fadeDistance.get())
                    a = dist / (fadeDistance.get() * fadeDistance.get());

                int prevLineA = lineColor.a;
                int prevSideA = sideColor.a;

                lineColor.a *= a;
                sideColor.a *= a;

                if (a >= 0.075) {
                    Renderer.boxWithLines(Renderer.NORMAL, Renderer.LINES, x1, y1, z1, x2, y2, z2, sideColor, lineColor, shapeMode.get(), excludeDir);
                }

                lineColor.a = prevLineA;
                sideColor.a = prevSideA;

                count++;
            }
        }
    });

    public StorageESP() {
        super(Category.Render, "storage-esp", "Renders all specified storage blocks.");
    }

    private void getTileEntityColor(BlockEntity blockEntity) {
        render = false;

        if (!storageBlocks.get().contains(blockEntity.getType())) return;

        if (blockEntity instanceof ChestBlockEntity) lineColor.set(chest.get());
        else if (blockEntity instanceof BarrelBlockEntity) lineColor.set(barrel.get());
        else if (blockEntity instanceof ShulkerBoxBlockEntity) lineColor.set(shulker.get());
        else if (blockEntity instanceof EnderChestBlockEntity) lineColor.set(enderChest.get());
        else if (blockEntity instanceof FurnaceBlockEntity || blockEntity instanceof DispenserBlockEntity || blockEntity instanceof HopperBlockEntity)
            lineColor.set(other.get());
        else return;

        render = true;

        if (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both) {
            sideColor.set(lineColor);
            sideColor.a -= 225;
            if (sideColor.a < 0) sideColor.a = 0;
        }
    }

    @Override
    public String getInfoString() {
        return Integer.toString(count);
    }
}
