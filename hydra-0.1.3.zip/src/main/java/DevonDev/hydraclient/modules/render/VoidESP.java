package DevonDev.hydraclient.modules.render;

import DevonDev.hydraclient.events.render.RenderEvent;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.rendering.Renderer;
import DevonDev.hydraclient.rendering.ShapeMode;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Color;
import DevonDev.hydraclient.utils.Dimension;
import DevonDev.hydraclient.utils.Utils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

public class VoidESP extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Colors");

    // General

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("horizontal-radius")
            .description("Horizontal radius in which to search for holes.")
            .defaultValue(64)
            .min(0)
            .sliderMax(256)
            .build()
    );

    private final Setting<Integer> holeHeight = sgGeneral.add(new IntSetting.Builder()
            .name("hole-height")
            .description("The minimum hole height to be rendered.")
            .defaultValue(1)  // If we already have one hole in the bedrock layer, there is already something interesting.
            .min(1)
            .sliderMax(5)     // There is no sense to check more than 5.
            .build()
    );

    // Render

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Sides)
            .build()
    );

    private final Setting<Color> sideColor = sgRender.add(new ColorSetting.Builder()
            .name("fill-color")
            .description("The color that fills holes in the void.")
            .defaultValue(new Color(225, 25, 25))
            .build()
    );

    private final Setting<Color> lineColor = sgRender.add(new ColorSetting.Builder()
            .name("line-color")
            .description("The color to draw lines of holes to the void.")
            .defaultValue(new Color(225, 25, 255))
            .build()
    );
    private final List<BlockPos> voidHoles = new ArrayList<>();
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        getHoles(horizontalRadius.get(), holeHeight.get());
    });
    @EventHandler
    private final Listener<RenderEvent> onRender = new Listener<>(event -> {
        for (BlockPos voidHole : voidHoles) {
            int x = voidHole.getX();
            int y = voidHole.getY();
            int z = voidHole.getZ();

            Renderer.boxWithLines(Renderer.NORMAL, Renderer.LINES, x, y, z, 1, sideColor.get(), lineColor.get(), shapeMode.get(), 0);
        }
    });

    public VoidESP() {
        super(Category.Render, "void-esp", "Renders holes in bedrock layers that lead to the void.");
    }

    private void getHoles(int searchRange, int holeHeight) {
        voidHoles.clear();

        BlockPos playerPos = mc.player.getBlockPos();
        int playerY = playerPos.getY();

        for (int x = -searchRange; x < searchRange; ++x) {
            for (int z = -searchRange; z < searchRange; ++z) {
                BlockPos bottomBlockPos = playerPos.add(x, -playerY, z);

                int blocksFromBottom = 0;
                for (int i = 0; i < holeHeight; ++i)
                    if (mc.world.getBlockState(bottomBlockPos.add(0, i, 0)).getBlock() != Blocks.BEDROCK)
                        ++blocksFromBottom;

                if (blocksFromBottom >= holeHeight) voidHoles.add(bottomBlockPos);

                // checking nether roof
                if (Utils.getDimension() == Dimension.Nether) {
                    BlockPos topBlockPos = playerPos.add(x, 127 - playerY, z);

                    int blocksFromTop = 0;
                    for (int i = 0; i < holeHeight; ++i)
                        if (mc.world.getBlockState(bottomBlockPos.add(0, 127 - i, 0)).getBlock() != Blocks.BEDROCK)
                            ++blocksFromTop;

                    if (blocksFromTop >= holeHeight) voidHoles.add(topBlockPos);
                }
            }
        }
    }
}
