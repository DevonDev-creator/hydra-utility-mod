package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class LiquidInteract extends ToggleModule {
    public LiquidInteract() {
        super(Category.Player, "liquid-interact", "Allows you to interact with liquids.");
    }
}
