package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.mixininterface.IKeyBinding;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.EnumSetting;
import DevonDev.hydraclient.settings.IntSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.Utils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class AutoClick extends ToggleModule {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .description("The method of clicking.")
            .defaultValue(Mode.Press)
            .build()
    );
    private final Setting<Button> button = sgGeneral.add(new EnumSetting.Builder<Button>()
            .name("Button")
            .description("Which button to press.")
            .defaultValue(Button.Right)
            .build()
    );
    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("The amount of delay between clicks in ticks.")
            .defaultValue(2)
            .min(0)
            .sliderMax(60)
            .build()
    );
    private int timer;
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        switch (mode.get()) {
            case Hold:
                switch (button.get()) {
                    case Left:
                        ((IKeyBinding) mc.options.keyAttack).setPressed(true);
                        break;
                    case Right:
                        ((IKeyBinding) mc.options.keyUse).setPressed(true);
                        break;
                }
                break;
            case Press:
                timer++;
                if (!(delay.get() > timer)) {
                    switch (button.get()) {
                        case Left:
                            Utils.leftClick();
                            break;
                        case Right:
                            Utils.rightClick();
                            break;
                    }
                    timer = 0;
                }
        }
    });

    public AutoClick() {
        super(Category.Player, "auto-click", "Automatically clicks.");
    }

    @Override
    public void onActivate() {
        timer = 0;
        ((IKeyBinding) mc.options.keyAttack).setPressed(false);
        ((IKeyBinding) mc.options.keyUse).setPressed(false);
    }

    @Override
    public void onDeactivate() {
        ((IKeyBinding) mc.options.keyAttack).setPressed(false);
        ((IKeyBinding) mc.options.keyUse).setPressed(false);
    }

    public enum Mode {
        Hold,
        Press
    }

    public enum Button {
        Right,
        Left
    }
}
