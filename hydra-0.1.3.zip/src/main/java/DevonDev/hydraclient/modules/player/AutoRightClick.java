package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.mixininterface.IKeyBinding;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Utils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class AutoRightClick extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .description("The method of right clicking.")
            .defaultValue(Mode.Press)
            .build()
    );
    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("The delay between clicks in ticks.")
            .defaultValue(2)
            .min(0)
            .sliderMax(60)
            .build()
    );
    private final Setting<Boolean> onlyWhenHoldingUse = sgGeneral.add(new BoolSetting.Builder()
            .name("only-when-holding-use")
            .description("Will work only when holding right click.")
            .defaultValue(false)
            .build()
    );
    private int timer;
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        if (mc.player.getHealth() <= 0) return;
        if (mode.get() == Mode.Hold && !mc.options.keyUse.isPressed()) {
            ((IKeyBinding) mc.options.keyUse).setPressed(true);
            return;
        } else if (mode.get() == Mode.Hold) return;

        timer++;

        if (timer > delay.get()) {
            if (onlyWhenHoldingUse.get()) {
                if (mc.options.keyAttack.isPressed()) Utils.rightClick();
            } else {
                Utils.rightClick();
            }

            timer = 0;
        }
    });

    public AutoRightClick() {
        super(Category.Player, "auto-right-click", "Automatically right clicks.");
    }

    @Override
    public void onActivate() {
        timer = 0;
    }

    @Override
    public void onDeactivate() {
        if (mode.get() == Mode.Hold && mc.options.keyUse.isPressed()) {
            ((IKeyBinding) mc.options.keyUse).setPressed(false);
        }
    }

    public enum Mode {
        Hold,
        Press
    }
}
