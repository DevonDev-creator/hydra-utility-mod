package DevonDev.hydraclient.modules.player;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;

public class Portals extends ToggleModule {
    public Portals() {
        super(Category.Player, "portals", "Allows you to use GUIs normally whilst in portals.");
    }
}
