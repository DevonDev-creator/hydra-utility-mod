/*
 * This file is part of the hydra Client distribution (https://github.com/hydraDevelopment/hydra-client/).
 * Copyright (c) 2020 hydra Development.
 */