package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;

public class Velocity extends ToggleModule {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> horizontal = sg.add(new DoubleSetting.Builder()
            .name("horizontal-multiplier")
            .description("How much velocity you will take horizontally.")
            .defaultValue(0)
            .min(0)
            .max(1)
            .sliderMin(0)
            .sliderMax(1)
            .build()
    );

    private final Setting<Double> vertical = sg.add(new DoubleSetting.Builder()
            .name("vertical-multiplier")
            .description("How much velocity you will take vertically.")
            .defaultValue(0)
            .min(0)
            .max(1)
            .sliderMin(0)
            .sliderMax(1)
            .build()
    );

    public Velocity() {
        super(Category.Movement, "velocity", "Prevents you from being moved by external forces.");
    }

    public double getHorizontal() {
        return isActive() ? horizontal.get() : 1;
    }

    public double getVertical() {
        return isActive() ? vertical.get() : 1;
    }
}
