package DevonDev.hydraclient.modules.movement;

import DevonDev.hydraclient.events.hydra.KeyEvent;
import DevonDev.hydraclient.events.packets.SendPacketEvent;
import DevonDev.hydraclient.mixininterface.IPlayerMoveC2SPacket;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.modules.render.Freecam;
import DevonDev.hydraclient.settings.DoubleSetting;
import DevonDev.hydraclient.settings.EnumSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.KeyAction;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Material;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;

public class AirJump extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<AirJump.Mode> mode = sgGeneral.add(new EnumSetting.Builder<AirJump.Mode>()
            .name("mode")
            .description("The mode used for bypasses.")
            .defaultValue(AirJump.Mode.None)
            .build()
    );
    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
            .name("speed")
            .description("Extra speed, use sparingly.")
            .defaultValue(0.1)
            .min(0)
            .sliderMax(0.5)
            .build()
    );
    private int jumpTicks;
    @EventHandler
    private final Listener<SendPacketEvent> onSendPacket = new Listener<>(event -> {
        if (event.packet instanceof PlayerMoveC2SPacket && mode.get() != Mode.None) {
            if (jumpTicks > 0) {
                if (mc.world.getBlockState(mc.player.getBlockPos().down()).getMaterial() == Material.AIR) {
                    ((IPlayerMoveC2SPacket) event.packet).setOnGround(true);
                }
                jumpTicks--;
            }
        }
    });
    private long jumpTime;
    @EventHandler
    private final Listener<KeyEvent> onKey = new Listener<>(event -> {
        if (ModuleManager.INSTANCE.isActive(Freecam.class) || mc.currentScreen != null) return;
        if ((event.action == KeyAction.Press && mc.options.keyJump.matchesKey(event.key, 0)) && !mc.player.isOnGround()) {
            if (mode.get() == Mode.Matrix) {
                mc.player.setSprinting(false);
                if (System.currentTimeMillis() - jumpTime < 300) {
                    return;
                }
                float g = mc.player.yaw * 0.017453292F;
                mc.player.setVelocity(mc.player.getVelocity().add(-MathHelper.sin(g) * speed.get(), 0.0D, MathHelper.cos(g) * speed.get()));
                jumpTicks = 1;
                jumpTime = System.currentTimeMillis();
            }
            mc.player.jump();
        }
    });

    public AirJump() {
        super(Category.Movement, "air-jump", "Lets you jump in the air.");
    }

    public enum Mode {
        None,
        Matrix,
    }
}
