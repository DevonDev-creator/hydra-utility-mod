package DevonDev.hydraclient.modules.combat;

import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.BoolSetting;
import DevonDev.hydraclient.settings.Setting;
import DevonDev.hydraclient.settings.SettingGroup;
import DevonDev.hydraclient.utils.Chat;
import DevonDev.hydraclient.utils.PlayerUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.Blocks;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;

public class SelfTrap extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> turnOff = sgGeneral.add(new BoolSetting.Builder()
            .name("turn-off")
            .description("Toggles off once the blocks are placed.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> selfToggle = sgGeneral.add(new BoolSetting.Builder()
            .name("self-toggle")
            .description("Toggles off when you run out of obsidian.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Forces you to rotate upwards when placing the obsidian.")
            .defaultValue(true)
            .build()
    );
    private boolean sentMessage = false;
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        int obsidianSlot = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.player.inventory.getStack(i).getItem() == Blocks.OBSIDIAN.asItem()) {
                obsidianSlot = i;
                break;
            }
        }

        if (obsidianSlot == -1 && selfToggle.get()) {
            if (!sentMessage) {
                Chat.warning(this, "No obsidian found… disabling.");
                sentMessage = true;
            }

            this.toggle();
            return;
        } else if (obsidianSlot == -1) return;

        int prevSlot = mc.player.inventory.selectedSlot;
        mc.player.inventory.selectedSlot = obsidianSlot;
        BlockPos targetPos = mc.player.getBlockPos().up(2);

        PlayerUtils.placeBlock(targetPos, Hand.MAIN_HAND);

        if (rotate.get()) {
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookOnly(mc.player.yaw, -90, mc.player.isOnGround()));
        }

        if (turnOff.get()) toggle();
        mc.player.inventory.selectedSlot = prevSlot;
    });

    public SelfTrap() {
        super(Category.Combat, "self-trap", "Places obsidian above your head.");
    }
}
