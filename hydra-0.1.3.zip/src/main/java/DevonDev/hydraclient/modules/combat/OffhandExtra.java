package DevonDev.hydraclient.modules.combat;

//Created by squidoodly 25/04/2020

import DevonDev.hydraclient.events.entity.player.RightClickEvent;
import DevonDev.hydraclient.events.world.PostTickEvent;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.modules.ModuleManager;
import DevonDev.hydraclient.modules.ToggleModule;
import DevonDev.hydraclient.settings.*;
import DevonDev.hydraclient.utils.Chat;
import DevonDev.hydraclient.utils.InvUtils;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class OffhandExtra extends ToggleModule {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("Mode")
            .description("Changes what type of item that will go into your offhand.")
            .defaultValue(Mode.Enchanted_Golden_Apple)
            .build()
    );
    private final Setting<Boolean> replace = sgGeneral.add(new BoolSetting.Builder()
            .name("replace")
            .description("Replaces your offhand, or waits until your offhand is empty.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> Asimov = sgGeneral.add(new BoolSetting.Builder()
            .name("Asimov")
            .description("Always holds the item specified in your offhand.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Integer> health = sgGeneral.add(new IntSetting.Builder()
            .name("health")
            .description("The health at which this stops working.")
            .defaultValue(10)
            .min(0)
            .sliderMax(20)
            .build()
    );
    private final Setting<Boolean> selfToggle = sgGeneral.add(new BoolSetting.Builder()
            .name("self-toggle")
            .description("Toggles when you run out of the item you choose.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> hotBar = sgGeneral.add(new BoolSetting.Builder()
            .name("search-hotbar")
            .description("Whether to take items out of your hotbar or not.")
            .defaultValue(false)
            .build()
    );
    private boolean isClicking = false;
    private boolean sentMessage = false;
    @EventHandler
    private final Listener<RightClickEvent> onRightClick = new Listener<>(event -> {
        assert mc.player != null;
        if (ModuleManager.INSTANCE.get(AutoTotem.class).getLocked() || !canMove()) return;
        if ((mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING || (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.get())
                && (mc.player.getOffHandStack().getItem() != getItem()) && !(mc.currentScreen instanceof HandledScreen<?>))) {
            isClicking = true;
            Item item = getItem();
            int result = findSlot(item);
            if (result == -1 && mc.player.getOffHandStack().getItem() != getItem()) {
                if (!sentMessage) {
                    Chat.warning(this, "None of the chosen item found.");
                    sentMessage = true;
                }
                if (selfToggle.get()) this.toggle();
                return;
            }
            boolean empty = mc.player.getOffHandStack().isEmpty();
            if (mc.player.getOffHandStack().getItem() != item && mc.player.getMainHandStack().getItem() != item && replace.get()) {
                InvUtils.clickSlot(InvUtils.invIndexToSlotId(result), 0, SlotActionType.PICKUP);
                InvUtils.clickSlot(InvUtils.OFFHAND_SLOT, 0, SlotActionType.PICKUP);
                if (!empty) InvUtils.clickSlot(InvUtils.invIndexToSlotId(result), 0, SlotActionType.PICKUP);
                sentMessage = false;
            }
        }
    });
    private boolean noTotems = false;
    @EventHandler
    private final Listener<PostTickEvent> onTick = new Listener<>(event -> {
        assert mc.player != null;
        if (!(mc.currentScreen instanceof InventoryScreen)) return;
        if (!mc.player.isUsingItem()) isClicking = false;
        if (ModuleManager.INSTANCE.get(AutoTotem.class).getLocked()) return;
        if ((Asimov.get() || noTotems) && !(mc.currentScreen instanceof HandledScreen<?>)) {
            Item item = getItem();
            int result = findSlot(item);
            if (result == -1 && mc.player.getOffHandStack().getItem() != getItem()) {
                if (!sentMessage) {
                    Chat.warning(this, "None of the chosen item found.");
                    sentMessage = true;
                }
                if (selfToggle.get()) this.toggle();
                return;
            }
            boolean empty = mc.player.getOffHandStack().isEmpty();
            if (mc.player.getOffHandStack().getItem() != item && replace.get()) {
                InvUtils.clickSlot(InvUtils.invIndexToSlotId(result), 0, SlotActionType.PICKUP);
                InvUtils.clickSlot(InvUtils.OFFHAND_SLOT, 0, SlotActionType.PICKUP);
                if (!empty) InvUtils.clickSlot(InvUtils.invIndexToSlotId(result), 0, SlotActionType.PICKUP);
                sentMessage = false;
            }
        } else if (!Asimov.get() && !isClicking && mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
            InvUtils.FindItemResult result = InvUtils.findItemWithCount(Items.TOTEM_OF_UNDYING);
            boolean empty = mc.player.getOffHandStack().isEmpty();
            if (result.slot != -1) {
                InvUtils.clickSlot(InvUtils.invIndexToSlotId(result.slot), 0, SlotActionType.PICKUP);
                InvUtils.clickSlot(InvUtils.OFFHAND_SLOT, 0, SlotActionType.PICKUP);
                if (!empty) InvUtils.clickSlot(InvUtils.invIndexToSlotId(result.slot), 0, SlotActionType.PICKUP);
            }

        }
    });

    public OffhandExtra() {
        super(Category.Combat, "offhand-extra", "Allows you to use specified items in your offhand. Requires AutoTotem to be on smart mode.");
    }

    @Override
    public void onDeactivate() {
        assert mc.player != null;
        if (ModuleManager.INSTANCE.get(AutoTotem.class).isActive()) {
            InvUtils.FindItemResult result = InvUtils.findItemWithCount(Items.TOTEM_OF_UNDYING);
            boolean empty = mc.player.getOffHandStack().isEmpty();
            if (result.slot != -1) {
                InvUtils.clickSlot(InvUtils.invIndexToSlotId(result.slot), 0, SlotActionType.PICKUP);
                InvUtils.clickSlot(InvUtils.OFFHAND_SLOT, 0, SlotActionType.PICKUP);
                if (!empty) InvUtils.clickSlot(InvUtils.invIndexToSlotId(result.slot), 0, SlotActionType.PICKUP);
            }
        }
    }

    private Item getItem() {
        Item item = Items.TOTEM_OF_UNDYING;
        if (mode.get() == Mode.Enchanted_Golden_Apple) {
            item = Items.ENCHANTED_GOLDEN_APPLE;
        } else if (mode.get() == Mode.Golden_Apple) {
            item = Items.GOLDEN_APPLE;
        } else if (mode.get() == Mode.End_Crystal) {
            item = Items.END_CRYSTAL;
        } else if (mode.get() == Mode.Exp_Bottle) {
            item = Items.EXPERIENCE_BOTTLE;
        }
        return item;
    }

    public void setTotems(boolean set) {
        noTotems = set;
    }

    public boolean getMessageSent() {
        return sentMessage;
    }

    private boolean canMove() {
        assert mc.player != null;
        return mc.player.getMainHandStack().getItem() != Items.BOW
                && mc.player.getMainHandStack().getItem() != Items.TRIDENT
                && mc.player.getMainHandStack().getItem() != Items.CROSSBOW;
    }

    private int findSlot(Item item) {
        assert mc.player != null;
        if (hotBar.get()) {
            return InvUtils.findItemWithCount(item).slot;
        } else {
            for (int i = 9; i < mc.player.inventory.size(); i++) {
                if (mc.player.inventory.getStack(i).getItem() == item) {
                    return i;
                }
            }
            return -1;
        }
    }

    public enum Mode {
        Enchanted_Golden_Apple,
        Golden_Apple,
        Exp_Bottle,
        End_Crystal,
    }

}
