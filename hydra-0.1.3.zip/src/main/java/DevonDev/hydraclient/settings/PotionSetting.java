package DevonDev.hydraclient.settings;

import DevonDev.hydraclient.gui.screens.settings.PotionSettingScreen;
import DevonDev.hydraclient.gui.widgets.WButton;
import DevonDev.hydraclient.gui.widgets.WItemWithLabel;
import DevonDev.hydraclient.utils.MyPotion;
import net.minecraft.client.MinecraftClient;

import java.util.function.Consumer;

public class PotionSetting extends EnumSetting<MyPotion> {
    public PotionSetting(String name, String description, MyPotion defaultValue, Consumer<MyPotion> onChanged, Consumer<Setting<MyPotion>> onModuleActivated) {
        super(name, description, defaultValue, onChanged, onModuleActivated);

        widget = new WItemWithLabel(get().potion);
        widget.add(new WButton("Select")).getWidget().action = () -> MinecraftClient.getInstance().openScreen(new PotionSettingScreen(this));
    }

    @Override
    public void resetWidget() {
        ((WItemWithLabel) widget).set(get().potion);
    }

    public static class Builder extends EnumSetting.Builder<MyPotion> {
        @Override
        public EnumSetting<MyPotion> build() {
            return new PotionSetting(name, description, defaultValue, onChanged, onModuleActivated);
        }
    }
}
