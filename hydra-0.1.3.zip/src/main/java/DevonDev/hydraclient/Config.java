

package DevonDev.hydraclient;

import com.g00fy2.versioncompare.Version;
import DevonDev.hydraclient.gui.GuiConfig;
import DevonDev.hydraclient.modules.Category;
import DevonDev.hydraclient.rendering.Fonts;
import DevonDev.hydraclient.utils.Color;
import DevonDev.hydraclient.utils.NbtUtils;
import DevonDev.hydraclient.utils.Savable;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.nbt.CompoundTag;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Config extends Savable<Config> {
    public static Config INSTANCE;

    public final Version version = new Version("0.1.3");
    public String devBuild;
    private String prefix = ".";
    public GuiConfig guiConfig = new GuiConfig();

    public boolean chatCommandsInfo = true;

    private Map<Category, Color> categoryColors = new HashMap<>();

    public Config() {
        super(new File(HydraClient.FOLDER, "config.nbt"));

        devBuild = FabricLoader.getInstance().getModContainer("hydra-client").get().getMetadata().getCustomValue("hydra-client:devbuild").getAsString();
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
        save();
    }

    public String getPrefix() {
        return prefix;
    }

    public void setCategoryColor(Category category, Color color) {
        categoryColors.put(category, color);
        save();
    }

    public Color getCategoryColor(Category category) {
        return categoryColors.get(category);
    }

    @Override
    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();

        tag.putString("version", version.getOriginalString());
        tag.putString("prefix", prefix);
        tag.put("categoryColors", NbtUtils.mapToTag(categoryColors));
        tag.put("guiConfig", guiConfig.toTag());
        tag.putBoolean("chatCommandsInfo", chatCommandsInfo);

        return tag;
    }

    @Override
    public Config fromTag(CompoundTag tag) {
        prefix = tag.getString("prefix");
        categoryColors = NbtUtils.mapFromTag(tag.getCompound("categoryColors"), Category::valueOf, tag1 -> new Color().fromTag((CompoundTag) tag1));
        guiConfig.fromTag(tag.getCompound("guiConfig"));
        chatCommandsInfo = !tag.contains("chatCommandsInfo") || tag.getBoolean("chatCommandsInfo");
        return this;
    }
}
